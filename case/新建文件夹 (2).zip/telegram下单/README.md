# 币安合约下单程序（两阶段保护 + 滚仓）

一个可以直接跑的下单执行器。**只负责执行，不负责产生信号**——信号从哪来（TG 频道、手工、你自己的策略）由你决定，喂给它就行。

当前默认配置：**3x 杠杆，每仓 50% 保证金（名义 150%）**，开仓先挂 **7% 止盈 + 5% 止损**兜底，收到真实止盈止损后 `amend` 替换。

## 一键运行

**Windows**：双击 `start.bat`

**Linux / VPS**：
```bash
chmod +x deploy/start_linux.sh
./deploy/start_linux.sh          # 交互菜单
./deploy/start_linux.sh 2        # 直接跑测试网真实下单
```

菜单长这样：

```
选择运行模式：

  [1] 测试网 + 只打印      最安全，验证信号解析
  [2] 测试网 + 真实下单    虚拟资金，可放心测
  [3] 回放历史消息         离线验证解析和下单逻辑
  [4] 检查配置             看环境/密钥/余额
  [5] 主网 + 真实下单      真实资金，谨慎
```

脚本会自动做三件事：检查 Python、首次运行装依赖、检查 `.env.bot` 是否存在。出问题会停住不让窗口闪退。

## 核心特性

| 特性 | 说明 |
|------|------|
| **两阶段保护** | 开仓先挂宽兜底止损（默认 7%），收到真实止盈止损后再 `amend` 替换。任何时刻都不裸仓 |
| **幂等下单** | `clientOrderId` 由信号内容哈希生成。同一个信号重复执行不会重复开仓，网络超时重试也安全 |
| **条件单止盈止损** | 交易所端 `STOP_MARKET` / `TAKE_PROFIT_MARKET`，机器挂了止损依然生效 |
| **裸仓保护** | 条件单挂失败会立刻市价平仓，绝不留无保护的仓位 |
| **逐仓隔离** | 每次开仓前强制设 `ISOLATED`（逐仓）：单仓爆仓最多亏该仓保证金，不牵连其他仓位。已有持仓/挂单时改不了，会拒绝开仓并提示先平仓 |
| **滚仓基于真实权益** | 每笔都重新读账户余额算仓位，不依赖内存变量，进程重启不跑偏 |
| **精度自适应** | 自动读 `exchangeInfo` 的 `stepSize` / `tickSize`，避免 `-1111` 精度错误 |
| **风控熔断** | 单笔上限、持仓数上限、日亏上限、连亏熔断 |
| **双重安全开关** | `testnet`（测试网）+ `dry_run`（只打印），默认都开着 |
| **心跳监控** | `/health` 端点供 UptimeRobot 之类的免费监控用 |

## 测试网 / 主网切换

**默认走币安测试网**（虚拟资金），不会碰到真钱。

| 方式 | 命令 | 说明 |
|------|------|------|
| 默认 | `python trader.py` | 读 `config.yaml` 的 `testnet: true` → 测试网 |
| 强制测试网 | `python trader.py --testnet` | 忽略配置，强制测试网 |
| 切主网 | `python trader.py --mainnet` | **真实资金**，需配主网 key |

启动时会打印当前环境，一眼能看出在哪个网：

```
================================================================
  环境:   测试网 TESTNET
  地址:   https://testnet.binancefuture.com
  模式:   LIVE 真实下单
  API Key: riufKUh5...u9fb
  杠杆:   3x | 每仓保证金 50% → 名义 150%
================================================================
```

### 两套密钥是分开的

测试网和主网的 API Key **不通用**，`.env.bot` 里分开放：

```bash
# 测试网（默认用这个）
BINANCE_API_KEY=...
BINANCE_API_SECRET=...

# 主网（加 --mainnet 才会用）
BINANCE_MAINNET_API_KEY=
BINANCE_MAINNET_API_SECRET=
```

程序按 `testnet` 开关自动选对应那套，不会混用。

**主网 key 没配时，`--mainnet` 会直接报错退出**，不会用测试网 key 去连主网（那样只会收到一堆 `-2015` 错误，很难排查）。

### 切主网前的检查清单

- [ ] 测试网已经跑通至少 20 笔，下单/改单/平仓都正常
- [ ] `.env.bot` 里 `BINANCE_MAINNET_API_KEY` / `BINANCE_MAINNET_API_SECRET` 已填
- [ ] 主网 API 权限只开「读取 + 合约交易」，**提现关闭**
- [ ] 主网 API 绑定了 VPS 公网 IP 白名单
- [ ] `margin_pct` 从 0.5 降到 0.1-0.2 先用小仓试
- [ ] 邮件通知能收到（余额跨档提醒）

## 止盈止损管理（三阶段）

回测 214 条真实信号得出的最优策略：

```
① 开仓       挂兜底 TP 7% / SL 5%
              ↓
② 收到真实值  止盈挂 TP3（最远目标），保存 TP1/TP2/TP3 全部价位
              ↓
③ TP1 到达    止损提到 TP1 外侧 0.5%，锁定利润，继续持有博 TP3
   TP2 到达    止损再提到 TP2 外侧 0.5%
   TP3 到达    止盈单自动成交
              ↓
④ 离场通知    市价平仓（双保险，防止条件单没触发）
```

### 为什么止盈挂 TP3 而不是 TP1

历史数据：**79% 能到 TP1，57% 能继续到 TP3**。挂 TP1 会过早落袋，挂 TP3 吃到最大利润。

### 为什么到 TP1 要把止损提上来

| 策略 | 每笔期望 |
|------|---------|
| 挂 TP3 不动 | +8.13% |
| 到 TP1 移止损到 TP1 | **+10.70%** |
| 到 TP1 直接平仓 | +6.21% |

到 TP1 后只有 72% 会继续走到 TP3，剩下 28% 会回落。把止损提上来，回落的单子也能吃 TP1 的利润，而不是吐回去变成止损。

### TP1/TP2 到达不平仓

频道发「TP1 止盈减仓」「TP2 已抵达」只是通知减仓，程序**不会平仓**，只把止损提上来。

### 只有这些词才平仓

`离场` / `平仓` / `止损了` / `打止损` / `全平` / `出局`

`止盈` / `TP1` / `TP2` **不触发平仓**。

### 改单失败时不会裸仓

改单是「撤旧单 → 挂新单」，中间任何一步失败都可能出现「旧单已撤、新单没挂上」。现在的处理：

| 情况 | 处理 |
|------|------|
| 新止损挂不上 | 用**旧止损价**回滚重挂；回滚也失败 → 立即市价平仓并告警 |
| 撤单结果查询失败 | 不假设旧单还在（可能已撤干净），继续挂新止损兜底 |
| 查询成功但确实还有挂单 | 安全放弃本次改单，保留旧保护 |
| 新止盈挂不上 | 止损保留，仓位仍有保护；目标价清单不清空，TP1 到达仍会移损 |
| 改单过程抛异常 | 数据放回重试队列，巡检继续重试，不会永久丢失 |

## 两阶段保护流程

频道发信号的节奏是「先发方向，1-2 分钟后再发止盈止损」，程序按这个节奏设计：

```
① 收到「现价空 #BTCUSDT」
   ↓
   python main.py open --symbol BTCUSDT --side short --entry 83500
   ↓
   立即市价开仓 + 挂 7% 止盈 + 7% 止损兜底
   空单示例：entry 83500 → TP 77655 (-7%) / SL 89345 (+7%)
   状态记为「待更新」，写入 state/pending_protection.json

② 收到「止盈：82000 止损：85000」
   ↓
   python main.py amend --symbol BTCUSDT --tp 82000 --sl 85000
   ↓
   撤掉兜底单 → 挂真实止盈止损，状态清除
```

**为什么兜底要 7% 这么宽：** 兜底的作用是防极端行情，不是执行策略。真实止盈止损通常 2-10%，7% 大致落在中间，不会太早误触发；等真实值到了再收紧。

**兜底期间的风险：** 这 1-2 分钟里仓位只有 7% 的保护。如果价格瞬间反向 6%，兜底还没触发而真实止损本该触发了——这是这个流程无法消除的代价，只能靠控制单笔仓位来限制。

**忘了 amend 怎么办：**

```bash
python main.py pending              # 查看哪些仓位还在等更新
python main.py pending --stale-minutes 5   # 标出超 5 分钟没更新的
```

超过 10 分钟没更新的仓位会在报告里标 ⚠️。也可以把它挂进 cron 定时检查。

## 邮件通知（余额跨档提醒）

余额每跨过一个档位就发一封邮件，不会每笔交易都刷。

### 关键失败告警（保护单 / 改单 / 平仓）

以下情况会**立刻发邮件**（主题带「【交易机器人告警】」），因为都可能导致仓位失去保护或平不掉：

| 场景 | 说明 |
|------|------|
| 开仓后保护单挂不上 | 止损挂失败，正在紧急平仓；紧急平仓也失败会再发一封 |
| 改单新止损挂不上 | 已用旧止损回滚；回滚也失败会紧急平仓 |
| 撤旧保护单未确认 | 可能重复挂单或裸仓，需要人工看一眼 |
| 止盈挂不上 | 止损仍在，仓位有保护，但止盈需要补挂 |
| 平仓单 0 成交 | 仓位还在，必须手动处理 |
| 平仓后仍剩仓位 | 部分成交，需要再平一次 |
| 平仓后持仓查询接口报错 | 平仓单已成交，但查不到结果、无法确认是否清零；**返回空持仓算平仓成功，不告警** |
| 改单/移损连续失败 | 止盈止损一直没生效，停在兜底保护 |

- 同一类失败 **60 秒内只发一封**，不会刷屏；不同币种/不同原因分别计数。
- **dry-run 和回放不发邮件**，只在日志里打印。
- 开仓失败（余额不足、价位不合理等）**不发邮件**——没仓位，不会亏钱。

### 配置

填到 `.env.bot`：

```bash
SMTP_SERVER=smtp.163.com
SMTP_PORT=465
SMTP_USER=your@163.com
SMTP_PASSWORD=授权码          # 163 用授权码，不是登录密码
SMTP_TO=your@qq.com
BALANCE_ALERT_THRESHOLD=2000  # 超过这个值开始提醒
BALANCE_ALERT_STEP=2000       # 每跨一个步长发一封
```

**163 授权码怎么拿**：163 邮箱 → 设置 → POP3/SMTP/IMAP → 开启 SMTP 服务 → 生成授权码（16 位字母）。

### 测试

```bash
python -c "
from config import load_config
from mailer import Mailer
c = load_config('config.yaml')
m = Mailer(c.smtp_server, c.smtp_port, c.smtp_user, c.smtp_password, c.smtp_to)
print('OK' if m.send_sync('测试', '邮件通道正常') else '失败')
"
```

### 开仓推送

每次开仓成功会自动发一封邮件，内容：

```
币种：BTCUSDT
方向：SHORT
成交价：83500
数量：0.0591
名义价值：4934.85 USDT
保证金：1644.95 USDT（3x）
止损价：89345
止盈价：77655
保护类型：兜底 7%（等真实止盈止损）
```

标题是 `【开仓】BTCUSDT SHORT`，手机上能直接看到。

### 余额提醒触发逻辑

| 余额 | 是否发邮件 |
|------|-----------|
| 1500 / 1999 | 不发（低于阈值） |
| 2100 | 发「突破 2,000 U」 |
| 2200 / 3900 | 不发（还在 2000 档内） |
| 4100 | 发「突破 4,000 U」 |

记录存在 `state/balance_alert.json`，重启不会重复发同一档。

### 已知坑

**Windows 中文主机名会导致 SMTP 崩溃**（`UnicodeEncodeError: ascii codec`）。代码里已用 `local_hostname="localhost"` 规避。Linux VPS 上不存在这个问题。

## 目录结构

```
tradebot/
├── trader.py                # 【自动跟单】TG 监听 → 解析 → 下单 主程序
├── signal_parser.py         # 消息解析器（可单独运行测试）
├── tg_listener.py           # Telethon 频道监听
├── main.py                  # 【手动】CLI 下单入口
├── binance_futures.py       # 币安 API 客户端（自实现签名）
├── executor.py              # 下单执行器（两阶段保护）
├── risk.py                  # 风控
├── notify.py                # Telegram 告警
├── mailer.py                # 邮件通知（余额跨档提醒）
├── config.py                # 配置加载
├── health.py                # 心跳 HTTP 服务
├── config.yaml              # 策略与风控参数
├── .env.bot                 # 密钥（不要提交到 git）
├── signals.example.json     # 批量信号示例
├── requirements.txt
└── deploy/
    ├── setup.sh             # VPS 一键初始化
    └── tradebot.service     # systemd 单元
```

## 两种用法

| 方式 | 命令 | 适用 |
|------|------|------|
| **自动跟单** | `python trader.py` | 监听频道，收到信号自动下单，收到止盈止损自动改单 |
| **手动下单** | `python main.py open ...` | 你自己看消息，手工敲命令 |

下面先说自动跟单，手动用法在后面。

## 自动跟单：TG 频道 → 币安

### 1. 申请 Telegram API

1. 手机/浏览器打开 **https://my.telegram.org**
2. 用**你的 TG 手机号**登录（不是 bot，是真人账号）
3. 点 **API development tools** → 随便填应用名（如 `mybot`）
4. 拿到 **api_id**（数字）和 **api_hash**（32 位字符串）

> 为什么用账号而不是 bot：Bot API 只能收到「bot 自己加入的群」的消息，公开频道加不进去。Telethon 用账号身份，能监听任意公开频道。

### 2. 配置

填到 `.env.bot`（推荐，密钥集中管理）：

```bash
TG_API_ID=12345678
TG_API_HASH=abcdef0123456789abcdef0123456789
TG_PHONE=+8613800138000
TG_CHANNEL=@channel_username
```

`TG_CHANNEL` 三种写法都行：`@用户名` / `https://t.me/xxx` / `-1001234567890`

### 3. 先用回放验证解析（不连 TG、不下单）

```bash
python signal_parser.py        # 单测解析规则
python trader.py --replay 历史消息.txt --limit 30
```

**回放的时间与平仓（重要）**：历史文件没有时间戳，回放用**虚拟时钟**按
`--msg-interval`（默认 60 秒/条）推进，避免把几天消息压缩成几秒导致 30 秒冷却误触发：

```bash
python trader.py --replay 历史消息.txt --limit 200 --msg-interval 60
```

回放还**不模拟价格涨跌**，所以：
- 仓位不会因价格触及止盈止损而自动平仓（只有到 TP3 才模拟平仓释放仓位槽）
- 开仓信号自带止盈止损的很少，多数是「先开仓、后补」，回放里这些兜底仓位不会自动平
- 结果就是开满 2 仓后新信号被「保证金不足」拒绝——**这是回放局限，不是 bug**

要看「真实能吃到多少单」，用滚仓模拟（按真实开/平顺序）：
`python roll_simulation.py`（工作区），它会报「实际成交 / 跳过」。

回放会把历史消息按顺序喂给解析器和下单逻辑，`dry_run` 下只打印。正常输出：

```
[007] OPEN    CROSSUSDT    short  tp=None sl=None
      [DRY-RUN][兜底] CROSSUSDT SHORT 48087 @~0.10263 名义 4935U 保证金 2467U
[008] TPSL    -            -      tp=0.1365 sl=0.166
      [DRY-RUN] amend CROSSUSDT SHORT SL 0.166 TP 0.1365
完成：开仓 2，改单 2，忽略 26，失败 0
```

看到「开仓 N，改单 N，失败 0」且 pending 清零，说明链路正常。

### 4. 启动实时监听

```bash
python trader.py
```

**首次运行会要求输入手机验证码**（TG 发给你），登录成功后生成 `tg_session.session` 文件，之后免登录。

> 如果账号开了两步验证，终端会让你输入密码。

### 5. 确认无误后开真实下单

```bash
# 测试网真实下单（先跑这个）
python trader.py --live

# 主网真实下单（确认测试网跑通后再来）
# 1. config.yaml 改 testnet: false
# 2. 换主网 API key
python trader.py --live
```

### session 被作废（AuthKeyDuplicatedError）怎么恢复

如果日志出现：

```
telethon.errors.rpcerrorlist.AuthKeyDuplicatedError: The authorization key
(session file) was used under two different IP addresses simultaneously
```

**不是代码 bug，是 Telegram 把这份 session 永久作废了**。原因只有两种：

1. 同一份 `.session` 被两台机器/两个进程同时使用；
2. 代理节点自动切换，出口 IP 变了，Telegram 认为同一 key 在两个 IP 上使用。

旧 session 不能再用，必须重新登录：

```bash
# 1. 先停掉所有在跑的 trader.py（两台机器都要停）
#    Windows: tasklist | findstr python
# 2. 运行重新登录脚本（旧文件会自动改名成 .session.bak，不会删）
python tg_login.py
#    按提示输入手机号 → Telegram 验证码 → 两步验证密码（如有）
# 3. 重新启动
python trader.py
```

要点：
- 同一份 session **只能一个进程/一台机器**用。两台机器都要跑，就各登录一次，
  `.env.bot` 里用不同的 `TG_SESSION`（如 `tg_session_a` / `tg_session_b`）。
- 代理固定一个节点，不要用「自动切换/负载均衡」；能直连就直连。
- 旧 `.session.bak` 不要再拷回来用，它已经失效。

#### 登录时报 `IncompleteReadError: 0 bytes read...`

这不是账号问题，是**代理到 Telegram 的连接被中断**（Clash 规则把 Telegram 走了直连、
节点屏蔽 Telegram、或 HTTP 代理对长连接不友好）。按顺序试：

```bash
# 1. Clash 切「全局」模式，换香港/日本/新加坡节点，再跑
python tg_login.py

# 2. 改用 socks5（Clash 7897 混合端口通常支持）
python tg_login.py --proxy socks5://127.0.0.1:7897

# 3. TUN 模式下试直连
python tg_login.py --no-proxy

# 4. 换 MTProto 连接方式
python tg_login.py --connection abridged
```

还不行就看 Clash 日志里 Telegram（`149.154.x.x` / `91.108.x.x`）命中了哪条规则，
命中 `DIRECT` / `REJECT` 就改成代理节点。

### 信号匹配逻辑（重要）

频道发信号的节奏是「先方向、1-2 分钟后止盈止损」，而且**止盈止损消息里没有币种名**。程序这样处理：

1. 收到 `#OGN 现价空` → 立即开仓 + 挂 7% 双向兜底
2. 收到 `止盈：0,0269-...` / `止损：0,0301` → 缓存
3. 两个都齐了 → 分配给「最早的待更新仓位」执行 amend

**多个仓位同时等待时，靠时间顺序 FIFO 匹配。** 如果频道一次推多个信号，可能错配——所以建议把 `max_open_positions` 设小（2-3），并在 `pending` 报告里核对。

止盈止损只收到一半时，`tpsl_ttl_sec`（默认 90 秒）后会告警提醒。

### 部署到 VPS 常驻

```bash
# systemd 单元已备好，ExecStart 改成 trader.py
sudo vi /etc/systemd/system/tradebot.service
#   ExecStart=/home/trader/tradebot/venv/bin/python trader.py

sudo systemctl start tradebot
sudo journalctl -u tradebot -f
```

**注意**：Telethon 首次登录需要交互输入验证码，建议先在 VPS 上手动跑一次 `python trader.py` 完成登录，再交给 systemd。session 文件生成后就免登录了。

---

## 手动下单（CLI）

### 1. 安装依赖

```bash
cd tradebot
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. 配置密钥

```bash
cp .env.example .env
vi .env
```

填三个东西：

- `BINANCE_API_KEY` / `BINANCE_API_SECRET`：币安后台创建，**权限只勾「读取」+「合约交易」，绝对不要勾提现**
- `TG_TOKEN` / `TG_CHAT_ID`：找 @BotFather 建 bot

### 3. 先验证，别急着下单

```bash
# 检查配置和连通性
python main.py check

# dry-run 试一笔（不配 key 也能跑，用虚拟 1000U 演示）
python main.py open --symbol BTCUSDT --side long --entry 81000 --tp 83000 --sl 80500
```

`dry-run` 模式下只会打印，不会真的下单。输出长这样：

```
[DRY-RUN] BTCUSDT LONG 0.0012 @~81000 名义 97.20U | SL 80500.0 TP 83000.0 | coid=OPa83ca9f5...
```

看到 `coid=` 说明幂等 ID 生成正常。

## 命令一览

```bash
python main.py check                  # 配置 / 连通性 / 账户检查
python main.py balance                # 查余额
python main.py positions              # 查持仓

# ① 开仓（只给方向，自动挂 7% 止盈 + 7% 止损兜底）
python main.py open \
  --symbol BTCUSDT --side short --entry 83500 \
  --id tg-20261109-001                # 信号唯一ID，用于幂等
# 可选覆盖：--margin-pct 0.5  --leverage 2  --provisional-sl 7  --provisional-tp 7

# ② 收到真实止盈止损后改单
python main.py amend --symbol BTCUSDT --tp 82000 --sl 85000

# 或者一次给全（跳过兜底，直接挂真实值）
python main.py open \
  --symbol BTCUSDT --side long \
  --entry 81000 --tp 83000 --sl 80500

# 查看还在等更新的仓位
python main.py pending
python main.py pending --stale-minutes 5

# 平仓
python main.py close --symbol BTCUSDT

# 批量执行信号文件
python main.py batch signals.json

# 常驻运行（心跳 + 自检）
python main.py serve
```

**切换真实下单**：命令行加 `--live`，或者把 `config.yaml` 里 `dry_run` 改成 `false`。

## 测试网端到端自测（真实消息完整链路）

主网下单前，想在测试网完整验证下单链路（真实测试网、虚拟资金），跑这个脚本。
**它走的是和实盘一模一样的代码路径**：真实 TG 消息文本 → `signal_parser.parse`
→ `Trader.on_message` → `Executor`，不是直接构造 Signal 的简化测试。

```bash
# 必须用 Python 3.9（工作区自带的 3.13 缺 requests/yaml）
# 直连币安若被 418 封，就带上 BINANCE_PROXY
BINANCE_PROXY=http://127.0.0.1:7897 py -3.9 testnet_e2e.py --mode split --symbol GRASSUSDT --side short --wait 8
```

两种模式（`--mode`），覆盖真实频道的两条主要路径：

**`--mode split`（默认推荐，频道最常见形态）**：开仓不带价位挂兜底，止盈/止损分两条发。

| 步骤 | 消息 | 验证点 |
|------|------|--------|
| ① | `#GRASSUSDT 现价空` | 兜底保护挂单 |
| ② | `止盈：...`（不带币种） | TPSLBuffer 缓存等齐 |
| ③ | `止损：...`（不带币种） | 补齐→无币种归属确认→改单 |
| ④ | `#GRASSUSDT TP2 已抵达` | 移损：误报安全跳过、保留保护 |
| ⑤ | `#GRASSUSDT 离场` | 市价平仓 + 清残留挂单 |

**`--mode full`**：信号自带多档止盈止损。开仓(自带三档止盈)→TPSL改单→TP1移损→离场平仓，
测 `tp_all` 多档解析和真实价位挂单。

参数：

```bash
--mode split|full    # 链路形态，见上
--symbol GRASSUSDT   # 币种（测试网有的话随便选；GRASS/BTC/ETH 都有）
--side short         # long / short
--wait 8             # 每步间隔秒数（默认 8，改单撤单确认需要几秒）
--sl-pct 6           # 开仓止损幅度（%），止盈固定三档 3/5/8%
```

**注意**：
- 脚本默认走测试网、真实下单（虚拟资金），会真的开仓/改单/平仓，不是 dry-run；
  告警邮件和 TG 推送在脚本里被替换成打印，不会真发。
- 每跑一次约 1 分钟（三~四个 `--wait 8`）。
- 依赖 `.env.bot` 里的测试网 key；若直连币安不通，按第「币安 418」节配 `BINANCE_PROXY`。
- 脚本在**工作区目录**（`C:/Users/hongji/WorkBuddy AI/.../testnet_e2e.py`），不在 bot 目录。
- **账户若有其它仓位/挂单锁着保证金**，新仓名义会自动按币安真实 `availableBalance` 下调
  （留 1% 安全垫），否则会被币安 `-2019 Margin is insufficient` 拒单。日志里会打印
  「币安可用 XXXU」。测试网账户有一笔历史全仓 BTC 空单，所以 GRASS 名义会被压到 ~3980U，属正常。
- 连亏 3 笔会触发风控熔断：熔断只挡新开仓，不挡平仓（离场信号照常执行），属预期行为。
- **主网首单前检查**：`python main.py positions` 确认无遗留全仓仓（模式列应为「逐仓」），
  无残留挂单；机器人开仓一律强制逐仓，但历史手动仓可能是全仓，会占用整个账户保证金。

## 信号文件格式

`signals.json`：

```json
[
  {
    "symbol": "BTCUSDT",
    "direction": "short",
    "entry": 83500,
    "tp1": 82000,
    "sl": 85000,
    "position_pct": 0.10,
    "signal_id": "tg-20261109-001"
  }
]
```

字段说明：

| 字段 | 必填 | 说明 |
|------|------|------|
| `symbol` | 是 | 币安合约交易对，如 `BTCUSDT` |
| `direction` | 是 | `long` / `short` |
| `entry` | 否 | 参考入场价，不填用当前标记价 |
| `tp1` | 否 | 止盈价。**省略则走兜底模式**，只挂 7% 止损等 amend |
| `sl` | 否 | 止损价。同上 |
| `position_pct` | 否 | 名义价值占权益比例，默认取 `config.yaml` |
| `signal_id` | 否 | 幂等标识，强烈建议填 |
| `provisional_sl_pct` | 否 | 兜底止损百分比，默认 7 |

给了 `tp1` 和 `sl` 就校验价位方向：多单必须 `sl < entry < tp1`，空单必须 `tp1 < entry < sl`，不满足直接拒绝。缺任一个则进入兜底模式，不做方向校验。

## 部署到 Linux VPS

### 一键安装

```bash
# 1. 上传（建议放英文路径，中文路径 systemd 会出问题）
scp -r "telegram下单" root@<VPS_IP>:/root/bot

# 2. 跑安装脚本（装依赖、建 venv、配防火墙、装 systemd、配日志轮转）
ssh root@<VPS_IP>
cd /root/bot
sudo bash deploy/setup.sh
```

脚本会自动做：

- 装 `python3-venv` / `ufw` / `chrony` / `logrotate`
- 建 venv 并装 `requirements.txt`
- 没有 `.env.bot` 就从模板复制并提示你填
- 防火墙只放行 SSH(22) + 心跳(8080)
- 生成 systemd 服务（路径自动适配）+ 日志轮转（保留 14 天）

### 填密钥

```bash
vi .env.bot
```

必填：`BINANCE_API_KEY` / `BINANCE_API_SECRET`、`TG_API_ID` / `TG_API_HASH` / `TG_PHONE` / `TG_CHANNEL`

填完再跑一次 `sudo bash deploy/setup.sh` 让它完成 systemd 安装。

### 首次登录 Telegram（必须手动）

Telethon 登录要输手机验证码，systemd 里没有 TTY，所以**必须先手动跑一次**：

```bash
cd /root/bot
./venv/bin/python trader.py
# 看到「监听已启动，等待消息...」后 Ctrl+C 退出
```

这一步会生成 `tg_session.session`，之后就不用再登录了。

> 也可以直接跑 `./venv/bin/python tg_login.py`，它只做登录、不会启动监听，更适合在 VPS 上单独操作。
> 如果报 `AuthKeyDuplicatedError`（session 被 Telegram 作废），同样用它重新登录，见上文「session 被作废怎么恢复」。

### 启动服务

```bash
sudo systemctl start tradebot
sudo journalctl -u tradebot -f      # 看日志
sudo systemctl status tradebot      # 看状态
curl -s localhost:8080/health       # 健康检查
```

### 监控

UptimeRobot 加一个 HTTP 监控，地址 `http://<VPS_IP>:8080/health`，间隔 5 分钟。进程挂了或卡死超过 120 秒，`/health` 返回 503 会触发告警。

**注意**：8080 端口对公网开放意味着别人也能看到你的持仓状态。介意的话把 ufw 里的 8080 删掉，只在服务器本地 curl。

### 常用运维命令

```bash
sudo systemctl restart tradebot     # 重启
sudo systemctl stop tradebot        # 停止
sudo journalctl -u tradebot --since "1 hour ago"   # 看最近一小时日志
```

## 风控参数

在 `config.yaml` 里调。当前默认是 **3x + 每仓 50% 保证金**：

```yaml
leverage: 3                      # 下单杠杆
margin_pct: 0.50                 # 每仓保证金占权益 → 3x 下名义 150%

max_leverage: 3                  # 杠杆上限
max_position_pct: 1.50           # 单笔名义敞口上限
max_margin_pct: 0.50             # 单笔保证金上限
max_total_margin_pct: 1.00       # 全部持仓保证金合计上限
max_open_positions: 2            # 最多同时持仓数
daily_loss_limit_pct: 0.20       # 当日亏 20% 停开新仓（3x 下约 2.6 笔止损）
max_consecutive_losses: 3        # 连亏 3 笔熔断

# 信号文本含这些词就跳过不开仓
skip_keywords:
  - 轻仓      # 建议小仓位的票，仓位不匹配自动跟单
  - 补仓      # 需要人工判断补仓时机的票

skip_limit_orders: true    # 挂单（限价）信号跳过，市价开会偏离进场区间
allow_reverse: false       # 同币反向信号：false 只告警跳过，true 自动反手
```

### 挂单信号为什么跳过

频道有两种开仓信号：

| 类型 | 样例 | 占比 | 处理 |
|------|------|------|------|
| 现价 | `#BTCUSDT 现价空` | 92.7% | 市价开仓 ✓ |
| **挂单** | `#NEARUSDT 挂单多 分批进场：3.13-3.08` | **7.3%** | **跳过** |

挂单信号给的是「在 3.13~3.08 之间分批挂限价单」，市价开仓会直接吃当前价（可能 3.20 或 3.00），偏离频道意图。设 `skip_limit_orders: false` 可以强行市价跟，但价位会不准。

### 反向信号为什么不自动反手

```
14:00  #BTCUSDT 现价空   → 开空
14:30  #BTCUSDT 现价多   → 当前持空，方向相反
```

默认 `allow_reverse: false` 会发告警并跳过：

```
⚠️ BTCUSDT 反向信号已跳过
   当前持有 SHORT，新信号 LONG
   要自动反手，把 config.yaml 的 allow_reverse 改成 true
```

原因是频道有时「空单还没离场又喊做多」，是加仓或对冲的意思，自动反手会平掉还在盈利的仓。改成 `true` 后会先市价平旧仓、再开新仓。

## 真实数据验证结果

用频道 **3413 条真实历史消息**跑完整流水（3x / 50% 保证金 / 权益 1000U）：

```
3413 条消息
├── IGNORE   2217  65.0%   广告/战绩/闲聊
├── OPEN      383  11.2%   开仓信号
├── TPSL      363  10.6%   止盈止损价位
├── TP_HIT    342  10.0%   TP1/TP2/TP3 到达
└── CLOSE     108   3.2%   离场通知

383 个开仓信号
├── 挂单信号跳过        28   7.3%
├── 排除词跳过         106  27.7%  (轻仓31 补仓52 两者23)
├── 反向信号告警跳过    30   7.8%
└── 实际开仓           177  46.2%
    └── 同向重复被拒     42   (同币已有同向持仓)
```

止盈目标分布（验证 TP3 策略的依据）：

| 目标个数 | 条数 | 占比 |
|---------|------|------|
| 3 个（TP1/TP2/TP3） | 319 | **90.4%** |
| 2 个 | 24 | 6.8% |
| 1 个 | 10 | 2.8% |

真实币价下的数量计算（测试网实盘账户 4934.56U）：

| 币种 | 标记价 | 下单量 | 名义 U | 占权益 |
|------|--------|--------|--------|--------|
| BTCUSDT | 73615.8 | 0.1005 | 7398.39 | **149.9%** |
| ETHUSDT | 2048.46 | 3.6130 | 7401.09 | **150.0%** |
| SOLUSDT | 83.0104 | 89.1600 | 7401.21 | **150.0%** |
| XRPUSDT | 1.0413 | 7108.2000 | 7401.77 | **150.0%** |
| DOGEUSDT | 0.0670166 | 110447.0 | 7401.78 | **150.0%** |

全部落在 150%，保证金 50%，兜底止损 = 成交价 ±5%、止盈 ±7%。

### 能开几个仓，取决于 margin_pct

| 每仓保证金 | 3x 下名义 | 最多仓数 | 总保证金 | 总名义敞口 |
|-----------|----------|---------|---------|-----------|
| **50%** | 150% | **2 个** | 100% | 300% |
| 45% | 135% | 2 个 | 90% | 270% |
| 30% | 90% | 3 个 | 90% | 270% |
| 25% | 75% | 3 个 | 75% | 225% |
| 15% | 45% | 6 个 | 90% | 270% |

当前默认 `margin_pct: 0.50` + `max_total_margin_pct: 1.00`，**两个仓各占 50% 保证金，合计 100%**，可以开满两仓。

### 第二仓按「剩余可用保证金」开

第一仓的保证金开仓后就锁定了，不随权益变化。所以第一仓亏损后，第二仓会按剩余额度自动缩水，而不是被直接拒绝：

| 场景 | 权益 | 第一仓锁定 | 可用 | 第二仓实际 | 名义 | 合计占比 |
|------|------|-----------|------|-----------|------|---------|
| 持平 | 500.0U | 250U | 250.0U | 250.0U | 750U | 100% |
| 亏 3% 价 | 477.5U | 250U | 227.5U | 227.5U | 682U | 100% |
| 亏 5% 价 | 462.5U | 250U | 212.5U | 212.5U | 637U | 100% |
| 亏 7% 价 | 447.5U | 250U | 197.5U | 197.5U | 592U | 100% |
| 亏 15% 价 | 387.5U | 250U | 137.5U | 137.5U | 412U | 100% |

如果可用额度不到目标的一半，会直接拒绝并提示「可用保证金不足」，不会硬开一个小仓。

### 3x 下的实际风险

| 项目 | 数值 |
|------|------|
| 单笔名义敞口 | 权益 × 1.5（150%） |
| 5% 价格止损 → 权益亏损 | **7.5%** |
| 两仓同时止损 | 15% 权益 |
| 逐仓爆仓距离 | 价格反向 **33.3%** |
| 止损到爆仓的安全边际 | 6.7 倍 |

**满仓的含义**：两仓都开满后没有余量开第三个仓，也无法追加保证金。逐仓模式下每仓独立强平（3x 需价格反向 33.3% 才爆），一个仓爆掉不会连带另一个，但账户权益会直接腰斩。

想留缓冲，把 `margin_pct` 降到 0.45（总 90%）。

熔断后需要人工干预，删掉 `state/daily_stats.json` 或把里面 `halted` 改成 `false`。

## 下单安全校验（宁可不下单，不可下错单）

### 0. 持仓模式必须匹配（否则止盈止损一个都挂不上）

币安账户有两种持仓模式，报单参数**完全不同**：

| | 单向 One-way | 双向 Hedge |
|---|---|---|
| `positionSide` | **不能带**（带了报 -4061） | **必须带** LONG/SHORT |
| 平仓 | `reduceOnly=true` | 不能带 reduceOnly，靠 positionSide |

旧版无条件带 `positionSide`，所以**单向账户（默认）下止损单必然被拒** →
`if not sl_id: raise` → 开完仓立刻紧急平仓，等于一单都留不住。

现在启动后自动探测一次（`GET /fapi/v1/positionSide/dual`，权重 30，只查一次），
按模式决定参数；如果运行中在币安改了模式，遇到 -4061 会自动翻转重试一次。

```
INFO binance_futures: 持仓模式：单向(one-way)
```

### 0.1 止盈挂不上 ≠ 要紧急平仓

止损是保命的，止盈只是赚钱的。旧版两者放在同一个 try 里，**止盈失败也会触发紧急平仓**——
白白付两次手续费还把好单丢了。

现在分开处理：

| 情况 | 处理 |
|------|------|
| 止损挂不上 | **紧急平仓**（绝不留裸仓） |
| 止盈挂不上 | 保留仓位（止损已生效），告警，等真实止盈止损到了再重挂 |
| 平仓前撤单失败 | **继续平仓**（撤单失败不该阻止你离场） |

### 0.2 开仓前先清掉历史挂单（幽灵单）

上一次仓位被止损平掉后，**旧的止盈单会留在交易所**（`closePosition=true` 的单在没仓位时不会成交，
但会一直挂着）。新仓位一开，它一触发就把新仓平掉——价格还是上一个仓位的价位。

现在开仓前先 `cancel_all`，清不掉就直接放弃开仓（宁可不下单，也不开一个可能被旧单误平的单）。

实测调用顺序：

```
DELETE allOpenOrders → POST marginType → POST leverage → POST order(MARKET)
                     → POST order(STOP_MARKET) → POST order(TAKE_PROFIT_MARKET)
```

### 0.3 无币种的止盈止损：按价位反推归属

频道经常发「止盈：xxx 止损：xxx」但不带币种。持仓 2 个时旧逻辑直接跳过，
结果**所有仓位永远停在兜底 5%/7% 上**，频道的真实止盈止损从来没生效过。

现在先按价位反推：只有**唯一一个**仓位的入场价能让这组价位落在合理区间（止损 0.5%~25%、
止盈 0.5%~60%）时才采用，否则仍然跳过。

| 持仓 | 收到 | 结果 |
|------|------|------|
| BTC 80000 / DOGE 0.07 | `止损：0.075 止盈：0.06` | → DOGEUSDT ✓ |
| BTC 80000 / DOGE 0.07 | `止损：84000 止盈：74000` | → BTCUSDT ✓ |
| BTC 80000 / DOGE 0.07 | `止损：1.5` | 都不沾边 → 跳过 ✓ |
| AAA 1.00 / BBB 1.02 | `止损：1.07` | 两个都合理 → 跳过（不猜）✓ |

### 1. 「平仓」不再一律当平仓指令

旧版 `CLOSE_KEYS` 里有裸「平仓」，导致这类消息被误判成平仓：

| 消息 | 旧版 | 现在 |
|------|------|------|
| `#BTCUSDT 现价多（平仓价参考 80000）` | **CLOSE** ❌ 把多仓平了 | OPEN ✓ |
| `#BTCUSDT 现价空，平仓后反手` | **CLOSE** ❌ 只平不开 | OPEN ✓ |
| `#ETHUSDT 现价多 目标 2500 平仓价看 2600` | **CLOSE** ❌ | OPEN ✓ |
| `#BTCUSDT 现价空（已平仓的不要跟）` | CLOSE ❌ | IGNORE ✓ |

现在只认明确的平仓表述：`离场 / 全平 / 出局 / 止损了 / 已平仓 / 平仓了 / 手动平仓 / 全部平仓`。

另外加了「不要跟 / 别跟 / 仅供参考 / 已经过了」→ 直接忽略。

### 2. 止盈止损不会再挂到错的币上

止盈止损消息**通常不带币种**，只能靠「最近一条开仓信号」推断归属。旧版只要 pending 只有 1 个就分配，会出现：

```
14:00  #AAAUSDT 现价空        → 开仓成功，pending={AAA}
14:01  #BBBUSDT 现价空（轻仓）  → 被排除词跳过，pending 仍是 {AAA}
14:02  止盈：0.1-0.2 止损：0.08  → 这是 BBB 的，却被挂到 AAA 上 ❌
```

现在加了两道校验：

```
止盈止损无币种，最近开仓信号是 BBBUSDT，但待更新仓位是 AAAUSDT，
无法确认归属，跳过（请手动 amend --symbol AAAUSDT）
```

- 最近一条开仓信号的币种 ≠ 待更新仓位 → 跳过
- 距最近开仓信号超过 5 分钟 → 跳过

同时会推 TG 告警，让你手动执行 `amend`。

另外，带非 USDT 币种的止盈止损（`#BTCUSDC 止盈：...`）直接忽略，不会退化成「无币种」去乱分配。

### 3. 市价单没成交不会假装成交

旧代码：

```python
filled = float(order.get("executedQty") or qty)   # executedQty="0" 时
```

`float("0")` 是 0.0（falsy），`or qty` 会返回**预期数量** —— 明明没成交，却当成全部成交，然后挂上止损止盈，实际根本没有仓位。

现在：

| 情况 | 处理 |
|------|------|
| `executedQty = 0` | **拒绝**，不挂保护单，告警 |
| 部分成交（< 95%） | 告警，按**实际数量**挂保护 |
| 滑点 > 2% | 告警（标记价 vs 成交价） |

### 4. 平仓后确认真的平掉了

平仓单也可能 0 成交或部分成交。旧代码直接删 `pending` 记录，导致仓位还在但程序以为平了（裸奔 + 记录丢失）。

现在：

```
平仓单未成交        → 报错，保留 pending，告警
平仓后仍剩 0.5 手   → 报错，保留 pending，提示手动 close
```

实测：

```
AAAUSDT 平仓后仍剩 0.5（部分成交），保留 pending 记录
⚠️ AAAUSDT 平仓后仍剩 0.5，未完全平掉
   请手动处理：python main.py close --symbol AAAUSDT
ok=False  error=平仓未完全成交，剩余 0.5
pending 是否保留: ['AAAUSDT']
```

### 5. 改单失败重试不再丢数据

止盈止损失败后会放进缓存等巡检重试（每 15 秒一次）。旧版重试有两个问题：

**问题 1：丢了 `tp_all`**

```python
amend_protection(sym, data["tp"], data["sl"])   # 没传 tp_all
```

amend 成功后 pending 里的 `tp_all` 变成只有 TP3，**后续 TP1/TP2 到达时无法移动止损**。

**问题 2：没传 `relaxed`**

移动止损后止损已经进到盈利区，重试时如果走「止损必须在入场价外侧」的严格校验，会被直接拒绝 → 重试 4 次全失败 → 止损永远停在旧位置。

现在两个都传：

```python
r = amend_protection(sym, data["tp"], data["sl"],
                     data.get("tp_all") or [], bool(data.get("relaxed")))
```

`restore()` 也会记住 `relaxed` 标志，重试时保持。

**问题 3：移动止损失败不重试**

`_handle_tp_hit` 里 amend 失败只加了个计数，没有放回缓存。现在会 `restore(..., relaxed=True)`，由巡检自动重试。

### 6. 一个会直接崩溃的 bug

`signal_parser.py` 的 `TPSLBuffer.restore()` 用了 `time.time()` 但文件里**没 import time**。

触发条件：amend 失败后 restore 一个不在缓存里的 symbol（正常流程就是这样，因为 feed 成功后会 pop）→ `NameError: name 'time' is not defined`。

也就是说 **每次改单失败都会抛异常**，只是被上层的 try/except 吞掉了，所以之前没发现。

### 7. 巡检不会因为没配通知而中断

`housekeeping` 里有几处 `self.notify(...)` 直接调用。如果 `notifier` 传的是 `None`（比如手动 CLI 场景），会 `TypeError`，导致**整轮巡检中断**（后面的 pending 清理、重试都不执行）。

现在全部加了 `if self.notify:` 判断。

### 8. pending 清理加了延迟

巡检查持仓时（现在只在有待管理仓位、且距上次 ≥ `pos_check_interval` 才查），仓位不在列表里就删 pending。但**刚开的仓可能因 API 延迟查不到**，会被误判成「已了结」。

现在只清理开仓超过 120 秒的记录。

### 9. 撤单接口用错了 HTTP 方法（导致旧单永远撤不掉）

币安撤销全部挂单的接口是：

```
DELETE /fapi/v1/allOpenOrders
```

旧代码写的是 `POST`，而 `_request()` 又只区分 GET 和其他（都走 POST），所以**每次撤单实际都是 POST 到一个只接受 DELETE 的地址** → 404。

后果：

| 场景 | 结果 |
|------|------|
| amend 改单 | 旧止损撤不掉 → 挂新止损 → **同一币两个止损单** |
| close 平仓 | 旧条件单撤不掉 → 平仓后残留孤儿单 |

两个止损单的价位不同时，先触发的那个平仓，另一个残留，下次开仓可能被它误触发。

修复：

```python
# _request 现在按真实方法发
if m == "GET":     resp = self.session.get(full, ...)
elif m == "DELETE": resp = self.session.delete(full, ...)
elif m == "PUT":   resp = self.session.put(full, ...)
else:              resp = self.session.post(full, ...)

# cancel_all 改用 DELETE
def cancel_all(self, symbol):
    return self._request("DELETE", "/fapi/v1/allOpenOrders", {"symbol": ...})
```

实测：

```
DELETE  https://testnet.binancefuture.com/fapi/v1/allOpenOrders   ✅
POST    https://testnet.binancefuture.com/fapi/v1/leverage
POST    https://testnet.binancefuture.com/fapi/v1/marginType
```

### 10. 撤单没确认就挂新单

撤单后轮询 10 次确认，但如果 10 次后挂单还在（或查询本身失败），旧代码会**继续挂新单** → 又变成两个止损单。

现在没确认成功就放弃本次改单：

```
AAAUSDT 撤旧保护单未确认（可能仍有挂单），拒绝挂新单
⚠️ AAAUSDT 撤旧保护单未确认，已放弃本次改单
   当前仍是旧保护单，请手动检查挂单
```

宁可这次不改，也不能重复挂单。

### 11. `--fetch` 会按历史信号真下单

`--fetch 50` 是拉最近 50 条历史消息走一遍逻辑。如果 `dry_run=False`，它会**按几小时前的信号在当前价开仓**——方向可能是对的，但价位已经完全错位。

现在强制 dry-run：

```
⚠️  --fetch 强制使用 DRY-RUN（历史信号不能用来真下单）
================================================================
  模式:   DRY-RUN 只打印
```

### 12. 精度规则每遇新币就拉一次全量

`exchangeInfo` 返回所有交易对的规则（响应约 1MB，权重 1）。旧代码每次遇到新币种都重新拉一遍全量，频道里几百个币种就是几百次请求。

现在只拉一次，全部缓存：

```
已加载 486 个交易对的精度规则    ← 整个进程只出现一次
```

### 13. 止盈止损价位没有「距离合理性」校验

旧代码只校验**方向**（多单止损在下方、空单在上方），不校验**距离**。

频道手滑多打一个 0：

```
#BTCUSDT 现价空 止盈：70000 止损：800000     ← 80000 打成 800000
```

方向校验通过（800000 > 80000），止损挂上去 → 价格涨到 80 万才触发 → **等于完全没有止损**。

现在三处都加了距离校验：

| 位置 | 止损上限 | 止盈上限 | 下限 |
|------|---------|---------|------|
| 开仓（信号自带价位） | 25% | 60% | 0.5% |
| amend（收到真实价位） | 25% | 60% | 0.5% |
| 移动止损（TP1/TP2 到达） | 入场价 ±50% 硬边界 | — | — |

实测：

```
正常 止损106(+6%) 止盈93(-7%)      ✅ 开仓
太近 止损100.3(+0.3%)            ❌ 太近会被立即触发，拒绝开仓
太远 止损200(+100%)              ❌ 超过 25% 上限，疑似写错，拒绝开仓
笔误 止损8000(+7900%)            ❌ 超过 25% 上限，疑似写错，拒绝开仓
```

### 14. 移动止损会挂出荒谬价位

`_handle_tp_hit` 算新止损：

```python
new_sl = target * 1.005    # 空单
if cur_sl and new_sl >= cur_sl:
    return                  # 只校验「不优于当前」
```

如果 `tp_all` 是错的（比如 `[3, 2, 1]`，实际是别的币的价位），入场价 100、当前止损 106：

```
new_sl = 3 × 1.005 = 3.015
3.015 < 106  → 通过校验 → 挂上止损 3.015
```

止损从 106 变成 3.015（远低于入场价 100），价格要涨到 3.015 才止损 → 实际上**永远不会触发**，裸奔。

现在加了硬边界（止损不能超出入场价 ±50%）：

```
BBBUSDT TP1 价位异常：目标 3，入场 100，算出的止损 3.015 超出 ±50% 边界，跳过移动止损
⚠️ BBBUSDT TP1 价位异常
   目标价 3，入场 100
   算出的止损 3.015 超出 ±50%，已跳过
   当前仍是旧止损 106.0
```

正常情况不受影响：

```
正常 TP1(93)，入场 100  →  新止损 93.465  ✅
```

### 15. 离线模拟的成交价恒为 1.0

`_offline_response` 里写的是：

```python
"avgPrice": str((params or {}).get("_px", 1.0))   # _px 从来没被设置过
```

导致回放/测试时所有成交价都是 1.0，数量算成 750（而不是按真实价位）。不影响实盘，但让测试数据失真、滑点告警误报。

现在用持仓的 mark 价。

## 防重复下单（四层）

Telegram 会把**点赞、表情回应、回复、置顶**都推成「消息编辑」事件，正文一个字没变。如果不拦，每条被点赞的旧信号都会重新解析一遍——既重复下单，又烧币安 API 权重。

四层防护：

| 层 | 机制 | 拦什么 |
|----|------|--------|
| 1 | `_seen` 消息 ID 去重（落盘 `state/seen_msgs.json`） | 同一条消息被投递多次（TG 重连重放） |
| 2 | `_last_text` 正文比较 | 点赞/表情/回复/置顶触发的假编辑 |
| 3 | 编辑后**同向忽略 / 反向反手** | 同向是补备注（防重复），反向是频道改主意（要跟） |
| 4 | 同币种 30 秒开仓冷却 | 兜底：任何原因导致的短时间重复触发 |

### 编辑开仓信号怎么处理

频道有时会编辑已发的开仓信号。分两种情况：

**情况 1：同向（只补备注、改标点）**

```
原消息：#BTCUSDT 现价空
编辑后：#BTCUSDT 现价空（注意控制仓位）
```

→ **忽略**，不重复开仓。日志：

```
编辑后仍是同向开仓 BTCUSDT short，忽略（防重复下单）
```

**情况 2：反向（频道改主意了）**

```
原消息：#BTCUSDT 现价空
编辑后：#BTCUSDT 现价多
```

→ **自动反手**：平掉空仓，开多仓。这条不受 `allow_reverse` 限制，因为是同一条消息的明确修正，不是新信号。日志：

```
🔄 信号被编辑，方向反转 BTCUSDT：SHORT → LONG，执行反手
平仓成交 | BTCUSDT SHORT | ... | 原因 edit-reverse | ...
开仓成交 | BTCUSDT LONG | ...
```

同时会推一条 TG 告警：

```
🔄 BTCUSDT 信号被编辑
   SHORT → LONG，正在反手
```

实测：

| 操作 | 结果 |
|------|------|
| 开空 → 编辑成同向 | 持仓不变，`ignore +1` |
| 开空 → 编辑成反向 | 平空开多，持仓从 -750 变 +750 |
| 编辑止盈止损 | 正常 `amend` 改单 |

**为什么反向编辑能自动反手**：这是频道对同一条消息的修正，意图明确。而「新消息发反向信号」默认只告警，因为那种情况可能是加仓或对冲。

## 空闲时不连币安（有信号才下单）

**程序不是长连接**：HTTP 每次请求独立，连接用完就断。真正占用的是「请求次数」。

旧版有三个地方在**没信号时也连币安**：

| 位置 | 旧行为 | 现在 |
|------|--------|------|
| `build()` 启动 | 主动同步服务器时间 | **懒同步**：第一次真正发签名请求时才校准 |
| `run_live()` 启动 | 查一次持仓并打印 | 默认关闭（`print_positions_on_start: false`） |
| `housekeeping()` | **每 15 秒无条件查一次持仓**，哪怕零仓位 | **事件驱动**：只有有待管理仓位时才查，间隔默认 5 分钟 |
| `cmd_serve()` 循环 | **每 60 秒主动 `ping` 一次**做存活检测，没信号也连 | 默认关闭（`health_ping_interval: 0`）；>0 才每 N 秒探一次 |

所以现在：

```
启动 → 零币安请求
空闲监听 → 零币安请求（巡检只做本地超时检查，不发网络）
收到开仓信号 → 才连币安：同步时间 + 查余额/持仓/价格 + 下单 + 挂保护单
收到止盈止损 → 才连币安：撤旧单 + 挂新单
有仓位时巡检 → 每 5 分钟查一次持仓（清理已被条件单平掉的记录）
```

日志会明确告诉你：

```
INFO 空闲巡检：无待管理仓位/改单，本轮零币安请求（只在有信号时才连币安）
```

配置（`config.yaml`）：

```yaml
pos_check_interval: 300          # 有仓位时多久查一次持仓（秒）
print_positions_on_start: false  # 改成 true 可恢复「启动打印持仓」（会发 1 次请求）
health_ping_interval: 0         # serve 模式主动探活间隔；0 = 不主动 ping（完全「有信号才连币安」）
```

### 连接类日志不再刷屏

网络异常 / 5xx / 429 / 时间戳偏差这几类警告改成**同类 60 秒最多一条**。
以前币安不可达时，一笔单重试 3 次就刷 3 条，加上巡检每 15 秒一轮，日志会被淹没。

---

## 条件单迁到 Algo Order API（2026-11 变更）

币安把**条件单**（STOP_MARKET / TAKE_PROFIT_MARKET）从 `/fapi/v1/order` 迁到了
**Algo Order 接口**。旧写法会报：

```
-4120 Order type not supported for this endpoint. Please use the Algo Order API endpoints instead.
```

后果：开仓成功但止盈止损挂不上 → 触发「裸仓保护」紧急平仓，每单白付手续费。

新写法（`binance_futures.py` 已适配）：

| | 旧 | 新 |
|---|---|---|
| 端点 | `POST /fapi/v1/order` | `POST /fapi/v1/algoOrder` |
| 类型 | 直接 type | 加 `algotype=CONDITIONAL` + `type` |
| 触发价 | `stopPrice` | **`triggerPrice`** |
| 幂等 | `newClientOrderId` | **`clientAlgoId`** |
| 返回 | `orderId` | `algoId`（已归一化成 orderId 兼容旧代码） |
| 查询 | `GET /fapi/v1/openOrders` | `GET /fapi/v1/openAlgoOrders` |
| 撤单 | `DELETE /fapi/v1/allOpenOrders` | **没有批量撤**，逐个 `DELETE /fapi/v1/algoOrder?algoId=` |

重复 `clientAlgoId` 仍报 `-4116`，`cancel_all()` 现在会同时撤普通单和 algo 单。

### ⚠️ 系统代理会导致 418（重要）

Windows 上开着 Clash/V2Ray 等系统代理（如 `127.0.0.1:7897`）时，Python 的
`requests` 默认会走系统代理，**代理的出口 IP 很可能被币安封禁**，表现为：
- `ping` / `time` 这类公开接口 200（可能被缓存/豁免）
- 但所有**签名接口**（下单/余额/持仓）返回 `418`，`Retry-After` 是几千秒

排查：`python -c "import urllib.request; print(urllib.request.getproxies())"`。
如果是代理导致，**绕过代理直连**即可（`curl` 不走系统代理所以往往 200，可对照）。

已默认修复：`BinanceFutures` 创建 session 时 `trust_env=False`，忽略系统代理。
确实需要代理时，设 `BINANCE_PROXY=http://127.0.0.1:7897` 显式指定。

---

## 币安 418 封禁（IP 被限）

### 418 是什么

币安的 `418 I'm a teapot` = **IP 被临时封禁**，原因是 1 分钟内的 API 权重超过 2400。

不是「长连接」的问题——HTTP 本来就是短连接，每次请求独立。真正的原因是**请求次数太多**。

封禁时长：
- 第一次：通常 2 分钟
- 反复触发：2 小时到 3 天

### 权重到底是谁花的（重要）

服务端的 `X-MBX-USED-WEIGHT-1M` 是**整个出口 IP 共享**的，不是按进程算。所以：

```
服务端报 2015/2400，本进程近 60 秒只用了 5
→ 消耗不是本进程产生的，同一个 IP 上还有别的消费者
```

常见原因，按概率排序：

1. **同一个机器人启动了多个实例**（`start.bat` 一个窗口 + 开机自启的 `pythonw` 一个）
2. 另一台机器/另一个程序共用同一个公网 IP（办公室 NAT、家里路由器）
3. 开了代理，代理出口 IP 被别人也在用

程序现在会把这个判断直接打进日志：

```
WARNING API 权重 2015/2400（84%），但本进程近 60 秒只用了 5 ——
消耗不是本进程产生的。请确认没有重复启动，或换个出口 IP
```

每 60 秒还有一行用量明细，能直接看出是哪个接口在刷：

```
INFO 近 60 秒共 18 次请求（本进程权重 62，服务端权重 240/2400）:
     positionRisk×6 balance×4 order×4 openOrders×3 premiumIndex×1
```

### 本进程正常用量（供对照）

| 场景 | 权重 |
|------|------|
| 开一笔仓（含挂止盈止损） | ~14 |
| 平一笔仓 | ~10 |
| 一次 amend 改单 | ~12 |
| 巡检（15 秒一轮，空闲零请求；有仓位时按 `pos_check_interval` 查持仓） | 0 / 有仓位时 5 每 5 分钟 |
| **一天 18 笔的日常运行** | **约 300（上限的 12%）** |

**如果日志显示每分钟几百次请求，那一定是循环/重复实例，不是正常下单。**

### 三重保护（现在的实现）

1. **本地权重预算**：发请求前先查自己近 60 秒用了多少，超过 1800 就先等，不硬撞
2. **418 期间零发包**：收到 418 会记住解封时间，期间所有请求在本地直接失败，一个包都不发（重试只会把 2 分钟变成 5 小时）
3. **改单失败分级**：「无持仓 / 价位不合理」这类永久失败不再重试；巡检每轮最多重试 3 个符号，避免几十个符号同时重试把权重打爆

### 被 418 之后怎么办

**什么都别做，等。** 反复重试会让封禁从 2 分钟变成几小时。

查还要等多久：

```bash
curl -i https://testnet.binancefuture.com/fapi/v1/ping
```

看响应头 `Retry-After`。程序日志也会写：

```
ERROR IP 处于币安封禁中，还需 292 分 15 秒。期间不发任何请求（避免封禁被延长）
```

期间只能跑 `--replay`（离线，零请求）。`--live` 和 `--fetch` 都会失败。

### 权重怎么算

| 接口 | 权重 |
|------|------|
| `/fapi/v1/premiumIndex`（查价） | 1 |
| `/fapi/v1/order`（下单/挂条件单） | 1 |
| `/fapi/v2/balance`（查余额） | 5 |
| `/fapi/v2/positionRisk`（查持仓） | 5 |
| `/fapi/v1/exchangeInfo`（精度规则） | 1（有缓存） |

**开一笔仓约 15 权重**（余额 5 + 持仓 5 + 查价 1 + 下单 1 + 挂止损 1 + 挂止盈 1 + 查价缓存 0）。

2400 / 15 = **每分钟能开 160 笔**。实盘每天 18 笔，完全不会超。

### 什么情况会被封

| 场景 | 是否安全 |
|------|---------|
| 实盘跟单（每天 10-30 笔） | ✅ 完全安全 |
| `--fetch` 拉历史消息 | ✅ 不涉及币安 API |
| **`--replay` 回放几百条** | ⚠️ 旧版每条都打 API，容易超 |
| 短时间内反复重启程序 | ⚠️ 每次重启都同步时间 + 拉 exchangeInfo |

### 已做的三处修复

**1. 回放改为完全离线**

`--replay` 现在用 `offline=True` 的客户端，**零 API 请求**：

```
INFO binance_futures: 离线模式：不连接币安（回放/测试用，零 API 权重）
```

回放时价格固定 1.0，数量会算成 750（500U × 50% × 3 / 1.0），但**名义/保证金/止损比例完全真实**，验证逻辑够用。

**2. 418 不再盲目重试**

旧代码遇到 418 会 `sleep 2/4/8 秒` 重试 3 次——**每次重试都在加深封禁**。

新逻辑：418 直接抛错，读 `Retry-After` 头告诉你还要等多久：

```
BinanceError: IP 被币安封禁（418），需等 120 秒。
原因是 API 权重超限，不要重试，等待后自动恢复
```

**3. 查价加 3 秒缓存**

同一币种 3 秒内重复查价（开仓算数量 + 挂单前校验）不再请求，省一半权重。

### 被封了怎么办

1. **什么都别做，等**。反复重试会让封禁时间翻倍
2. 查看还要等多久：
   ```bash
   curl -i https://testnet.binancefuture.com/fapi/v1/ping
   ```
   看响应头 `Retry-After` 的秒数
3. 等完之后第一次请求就会成功
4. 如果是家庭宽带，重启光猫可能换 IP（不保证）

## 已知限制

**设计原则：宁可漏单，不可错单。** 下面几条都是这个原则的具体体现。

1. **只支持币安 USDT 本位合约**。`#BTC` 会自动补成 `BTCUSDT`；`BTCUSDC` / `BTCBUSD` 直接拒绝；不存在的币种在下单前就会被拦下。
2. **方向有歧义时拒绝**。一条消息里同时出现「现价空」和「现价多」时不开仓，避免反向开错。
3. **多个待更新仓位时，不带币种名的止盈止损会被跳过**。频道发 `止盈：xxx 止损：xxx` 但没写币种、而你同时有 2 个以上待更新仓位时，程序**不会猜**（FIFO 可能把止损挂到错的币上），而是记日志让你手动 `amend`。
4. **战绩统计消息会被过滤**。`获利：24单 止损：4单` 这类消息里的数字不会被当成价格。
5. **`amend` 有 1-2 秒裸奔窗口**。撤旧单到挂新单之间仓位无保护。币安合约不支持直接修改条件单的 `stopPrice`，只能撤+挂。
6. **`closePosition=true` 的条件单会平掉整个仓位**。要分批止盈（TP1 平一半）得改成带 `quantity` 的 `reduceOnly` 单。
7. **兜底 7% 对宽止损币会偏紧**。真实止损 10% 的币，7% 兜底会提前触发。这类币建议开仓时直接给 `--sl`。
8. **1x 合约做空要付资金费率**。按 0.01%/8h 算，一个月约 0.9%。
9. **测试网和主网是两套账户**。密钥不通用，`.env.bot` 里分开配。
10. **不支持双向持仓模式**。检测到同币种两个方向持仓时会直接拒绝，请先在币安切回单向。

## 上线前的检查清单

- [ ] 测试网跑通至少 20 笔，观察滑点和成交价与信号的偏差
- [ ] API Key 权限确认只有「读取 + 合约交易」，提现是关的
- [ ] VPS 公网 IP 已加入币安 API 白名单
- [ ] `.env` 权限是 600（`chmod 600 .env`）
- [ ] SSH 已禁用密码登录
- [ ] UptimeRobot 监控已配置并测试过告警
- [ ] Telegram 告警能正常收到
- [ ] 主网第一笔用最小资金（比如 50U 权益）

## 免责声明

这是执行工具，不含任何策略。信号本身值不值得跟，需要你自己判断。加密合约交易可能导致全部本金损失，请只投入能承受损失的资金。
