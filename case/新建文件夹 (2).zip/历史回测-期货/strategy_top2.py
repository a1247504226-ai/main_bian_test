# -*- coding: utf-8 -*-
"""
「展期收益 + 趋势」多品种策略  ——  实盘信号 + 邮件通知 + 历史回测
单文件，只依赖同目录 data/*.csv，可直接运行。

━━━ 品种分层：本金涨了自动加品种 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
默认 2 万 → 只跑 玻璃 FG + 热卷 HC（1 手保证金合计约 5,850 元）。
本金变大后，只要改 EQUITY，CAPITAL_TIERS 里够门槛的品种会自动加入；
每个品种仍受「杠杆护栏 + 波动率目标仓位」约束，不会因为品种多了就超风险。

    2 万起   玻璃 FG / 热卷 HC              ← 默认起点
    3 万起  + 螺纹钢 RB / 纯碱 SA
    6 万起  + 短纤 PF / 棉花 CF
   11 万起  + 沪镍 NI
   16 万起  + 焦煤 JM
   20 万起  + 橡胶 RU                       ← 时序路线的最后一档

   只收「只多、只空【都为正】」的品种（收益不靠市场漂移，可重复）。
   剔除的品种与理由见下方配置区注释。
   ※ 焦炭 J 已剔除：样本内 +34.5% / 样本外 −2.0%，典型过拟合。
   ※ 29 万以上别再往时序池里加品种了 —— 换横截面策略（见
      「期货策略第二轮研究报告.html」），Calmar 0.56 且与现有策略相关仅 0.19，
      50/50 组合后 Calmar 1.00。但需要同时持有 10 个品种，约 29 万本金。

━━━ 策略逻辑（三条腿同时成立才持仓）━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
① 展期收益 carry —— 决定「做多还是做空」
   主连是主力合约的【不复权】拼接，换月当天价格会跳到新合约价位：
       近月 100 / 远月 105（contango 升水）→ 主连换月日跳空 +5%
   但这个 +5% 不是交易者拿到的收益 —— 真实持仓者是卖掉 100 的合约、
   换成 105 的合约，随后新合约要向现货收敛 105 → 100，【实亏 5%】。
   所以：累计跳空为正 = 该品种长期升水 = 持有【多头】在付展期成本。
       过去 252 日累计跳空 > +0.4%  → 长期 contango    → 只做空
       过去 252 日累计跳空 < -0.4%  → 长期 backwardation → 只做多
       介于两者之间                 → 空仓（没有展期收益可赚）

② 趋势确认 —— 决定「什么时候进」
   EMA20 与 EMA60 的方向必须与 carry 一致，否则空仓。
   carry 给方向，趋势给时点；两者打架就不做。

③ 波动率目标仓位 —— 决定「下多少手」
   敞口 = min(2.0, 2% / 日波动率)        日波动率 = ATR20 / 前收盘
   目标手数 = 敞口 × 账户权益 / (现价 × 合约乘数)
   波动大的品种自动少开、波动小的自动多开，让每个品种贡献相同的风险。

━━━ 执行时点（严格无前视）━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   T 日收盘算出信号  →  T+1 日【开盘】调仓

   注意：「T+1 开盘」= 【T 日当晚 21:00 的夜盘】，不是第二天 9:00。
   中国期货的一个「交易日」= 前一自然日 21:00 夜盘 + 当日日盘。
   实测（玻璃 FG，2026-10-12）：
       10-09 21:05~23:00 夜盘 + 10-12 09:05~15:00 日盘 合并后
       open 870 / high 875 / low 860 / close 863
     与实际日线 10-12   open 869 / high 875 / low 860 / close 863 吻合。
   所以 T 日收盘出的信号，最早能成交的时点就是【T 日 21:00】。
   运行脚本的时点不敏感（15:30~20:55 之间跑，信号完全一样），
   真正敏感的是【下单时点】—— 拖到第二天 9:00 就比回测假设晚了半天。
   例外：长假前最后一个交易日没有夜盘，那天要等下一个交易日 9:00。

   回测证明日线硬止损是负贡献（只在震荡里反复砍仓），故不设止损；
   风险控制完全交给「波动率目标仓位 + 杠杆护栏」。

━━━ 邮件推送规则 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
每个交易日推【两封】：早盘前（08:00）+ 晚盘前（20:00），两种形态：
  · 有仓位变动  → 标题「【⚠ 期货信号·有变更】…」高亮提醒，正文先列操作清单
  · 无仓位变动  → 标题「【期货信号·持仓】… 浮盈 +440 元」，正文列持仓与盈亏
正文是手机友好的 HTML 表格（固定列宽，窄屏不折行），另有纯文本兜底。
盈亏按 signal_state.json 记录的开仓价计算；跟踪权益 = 起始权益 + 已实现 + 浮动。
两场用不同去重键（notified.am / notified.pm），同一天两封都会发；同一场重复
运行不会重复发。早盘那封会用【夜盘最新价】算浮盈（当天没走完的 K 线只取价
格、不参与信号）。想强制再发一封加 daily。

━━━ 用法 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   python strategy_top2.py             # 打印今天的信号 + 跑回测
   python strategy_top2.py signal      # 只打印今天的信号（不发邮件）
   python strategy_top2.py notify      # 发当日邮件（按当前小时自动判断场次）
   python strategy_top2.py notify am   # 指定早盘场次（08:00 跑）
   python strategy_top2.py notify pm   # 指定晚盘场次（20:00 跑）
   python strategy_top2.py notify daily# 强制发送（该场次已发过也再发一封）
   python strategy_top2.py notify test # 只打印邮件内容，不真发（排查用）
   python strategy_top2.py backtest    # 只跑回测
   python strategy_top2.py test-mail   # 发两封样例邮件（有变更 / 无变更）
   python strategy_top2.py refresh     # 只更新 data/ 下的行情 CSV

   数据：读取同目录 data/{代码}.csv（date,open,high,low,close,volume）。
        缺数据时自动用 akshare 拉取（需 pip install akshare）。
"""
import os
import sys
import json
import math
import time
import smtplib
import statistics
import shutil
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
from email.utils import formataddr, formatdate

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")

TRADING_DAYS = 244          # 中国商品期货年均交易日
WARMUP = 250                # 前 250 根 K 线不出信号（等指标预热）


# ══════════════════════════════════════════════════════ 配置区
EQUITY = 20000.0            # 账户权益（元）—— 本金涨了就改这里，品种会自动增加

# ══════════════════════════════════════════════════════════════════════
#  品种池：只收「只多和只空【都为正】」的品种
#
#  为什么用这个标准：主连复权后仍残留真实现货升值（δ≈+1.7%/年）。
#  一个品种若【只空为负】，说明它的收益全来自市场上涨，换个年份就没了；
#  只有【两侧都为正】，才说明 carry+趋势 在这品种上是可重复的 edge。
#
#  逐品种实测（carry+趋势，波动率目标 2%，无止损）：
#    收进池子（只空>0）：
#      FG 玻璃  +11.4%  只空 +2.8%   门槛  2万  ← 样本外 +12.4%，最稳
#      RB 螺纹钢 +10.2%  只空 +6.3%   门槛  3万  ← 空侧最强
#      NI 沪镍  + 9.1%  只空 +0.9%   门槛 11万  ← Calmar 0.55 全场最高
#      HC 热卷  + 9.1%  只空 +0.6%   门槛  2万  ← 样本外 +11.1%
#      JM 焦煤  + 8.0%  只空 +1.8%   门槛 16万
#      SA 纯碱  + 4.9%  只空 +0.7%   门槛  3万  ← 保证金最便宜的补充
#      RU 橡胶  + 4.5%  只空 +2.0%   门槛 20万  ← 样本外 −0.1%，勉强
#      CF 棉花  + 3.5%  只空 +1.9%   门槛  6万
#      PF 短纤  + 3.5%  只空 +1.2%   门槛  6万  ← 回撤仅 13.5%，全场最低
#    剔除（只空≤0，收益靠漂移）：
#      I 铁矿石 +10.5% 只空 −0.2%   UR 尿素 +4.2% 只空 −0.1%
#      M 豆粕   + 2.5% 只空 −3.1%   C 玉米  −1.9% 只空 −2.4%
#      RM 菜粕  − 2.6% 只空 −2.4%   CS 淀粉 −2.7% 只空 −0.6%
#    剔除（样本外转负 = 过拟合）：
#      J 焦炭   +14.7% 只空 +9.3%  但 样本内 +34.5% / 样本外 −2.0%
#      —— 全池年化最高，但那是 2013-2018 的行情，近年已失效，不进池
#    单独说明：
#      LH 生猪 +14.9% 但只多 −2.8% / 只空 +18.2% —— 单边押注，
#      且只有 2021 年至今 5.7 年数据，骑的是猪价单边熊市，不进核心池。
#
#  门槛 ≈ MIN_FILL × 2 × 1手名义 / 敞口（按同时持有 2 个品种估），
#  实际能否持仓由运行时决定（信号 + MIN_FILL + 保证金预算 + 杠杆护栏）。
# ══════════════════════════════════════════════════════════════════════
CAPITAL_TIERS = [
    # 1 手名义 1.7~3.3 万，波动率敞口 0.8~2.0 —— 小资金唯一能碰的一层
    {"name": "2万起", "min_equity": 0,
     "syms": [("FG", 20, 0.09), ("HC", 10, 0.07)]},
    {"name": "3万起", "min_equity": 30000,
     "syms": [("RB", 10, 0.07), ("SA", 20, 0.09)]},
    {"name": "6万起", "min_equity": 60000,
     "syms": [("PF", 5, 0.08), ("CF", 5, 0.07)]},
    {"name": "11万起", "min_equity": 110000,
     "syms": [("NI", 1, 0.12)]},
    {"name": "16万起", "min_equity": 160000,
     "syms": [("JM", 60, 0.12)]},
    # 收益靠前但样本外衰减的品种不进池（焦炭 J 已剔除，见上方注释）
    {"name": "20万起", "min_equity": 200000,
     "syms": [("RU", 10, 0.10)]},
]

# 手动指定品种（设成列表则忽略 CAPITAL_TIERS 自动分层）；None = 自动
INSTRUMENTS = None

LOTS_MODE = "auto"          # "auto" = 按波动率目标动态算手数（随本金缩放）
                            # "fixed" = 每腿固定 LOTS_PER_LEG 手
LOTS_PER_LEG = 1            # LOTS_MODE="fixed" 时生效

VOL_TARGET = 0.025          # 单品种日波动率目标 2.5%
                           # 2026-10-20 由 0.02 上调。实测（2014-03 ~ 2026-10）：
                           #   0.020 → 年化 15.41%  回撤 23.4%  Calmar 0.66  Sharpe 0.97
                           #   0.025 → 年化 18.96%  回撤 25.1%  Calmar 0.76  Sharpe 1.05
                           # 0.025 是 Calmar/Sharpe 最优点；样本内 18.39% / 样本外 19.31%，
                           # 内外一致说明不是拟合出来的。
                           # 代价：最差年份从 2017 的 -7.0% 变成 2023 的 -11.7%。
                           # 想回旧档：改回 0.02 即可。
EXPO_CAP = 2.0              # 单品种敞口上限（名义价值 / 权益）
MIN_FILL = 0.50             # 目标手数低于此值就不开仓
                            # —— 目标 0.1 手却开 1 手，实际风险是目标的 10 倍
MARGIN_BUDGET = 0.50        # 全部持仓的保证金占用上限（占权益）
MARGIN_SAFE = 0.60          # 单腿保证金超过权益此比例则不再开新仓
STALE_DAYS = 5              # 某品种数据落后「最新品种」超过这么多个自然日，就剔除不参与
                           # —— 拿旧信号的品种去分新信号的钱，仓位和浮盈都会串味
MAX_LEG_LEVERAGE = 3.0      # 单腿「名义/权益」上限。1 手就超过 3 倍的品种直接不做
                            # —— 例：1 手沪金名义 90 万，在 2 万账户上是 45 倍杠杆，必爆

CARRY_WIN = 252             # carry 回看窗口（约 1 年）
CARRY_THR = 0.004           # carry 阈值 0.4%
MA_FAST, MA_SLOW = 20, 60   # 趋势确认用双均线
ATR_N = 20                  # ATR 周期
GAP_THRESH = 0.03           # |跳空| 超过 3% 判定为换月（阈值 1%~3% 是平稳平台）
FEE = 0.0002                # 手续费 2bp
SLIP = 0.0005               # 滑点 5bp
BROKER_ADD = 0.04           # 期货公司保证金加收（交易所口径 +4pp）

STATE_FILE = os.path.join(HERE, "signal_state.json")   # 记录上次已通知的仓位

# ── 邮件配置（163 邮箱，SMTP over SSL 465）─────────────────────────
# ⚠️ 这是授权码不是登录密码。若要把本脚本发给别人，请先删掉这一段。
MAIL = {
    "enabled": True,
    "from": "a1247504226@163.com",
    "to": "1247504226@qq.com",
    "password": "XKCINXNMOMMDCAFI",
    "server": "smtp.163.com",
    "port": 465,
    "max_retries": 3,
}

NAME = {"FG": "玻璃", "HC": "热卷", "RB": "螺纹钢", "SA": "纯碱", "NI": "沪镍",
        "LH": "生猪", "J": "焦炭", "I": "铁矿石", "C": "玉米", "CS": "玉米淀粉",
        "RM": "菜粕", "V": "PVC", "M": "豆粕", "TA": "PTA", "MA": "甲醇", "PF": "短纤",
        "JM": "焦煤", "AL": "沪铝", "UR": "尿素", "AG": "沪银", "AU": "沪金",
        "CU": "沪铜", "Y": "豆油", "P": "棕榈油", "PP": "聚丙烯", "SM": "锰硅",
        "SF": "硅铁", "SP": "纸浆", "CF": "棉花", "AP": "苹果", "OI": "菜油",
        "PK": "花生", "CJ": "红枣", "EG": "乙二醇", "L": "塑料", "V": "PVC",
        "ZN": "沪锌", "RU": "橡胶", "BU": "沥青", "SC": "原油", "SI": "工业硅",
        "LC": "碳酸锂", "SS": "不锈钢", "FU": "燃油", "AO": "氧化铝"}


def active_instruments(equity=None):
    """按账户权益选出当前该跑的品种（分层自动启用）。"""
    if INSTRUMENTS is not None:
        return list(INSTRUMENTS)
    eq = EQUITY if equity is None else equity
    out = []
    for t in CAPITAL_TIERS:
        if eq >= t["min_equity"]:
            out.extend(t["syms"])
    return out


# ══════════════════════════════════════════════════════ 数据层
def read_csv(sym):
    """读本地 CSV，并做「排序 + 去重 + 剔除非法价」三道加固。

    为什么必须排序：复权、EMA、ATR、carry 全部假设序列按日期递增。
    一旦 CSV 乱序，复权因子会按错序累乘，信号与回测全错，而且不报错。
    去重：同一天出现两行会令 gap 误判成换月跳空。
    剔除非法价：NaN 或 <=0 的价格会让后续比较变成 False ——
    sig_carry 的 `s < -thresh` 对 NaN 恒为 False，信号会静默变成「做空」，
    这是最危险的一种错法。
    """
    path = os.path.join(DATA, sym + ".csv")
    if not os.path.exists(path):
        return None
    bars, seen = [], set()
    with open(path, encoding="utf-8") as f:
        next(f, None)
        for line in f:
            q = line.strip().split(",")
            if len(q) < 6:
                continue
            try:
                d = q[0]
                o, h, l, c, vol = (float(q[1]), float(q[2]), float(q[3]),
                                   float(q[4]), float(q[5]))
            except ValueError:
                continue
            if d in seen:
                continue
            if any(v != v or v <= 0 for v in (o, h, l, c)):
                continue
            seen.add(d)
            bars.append({"date": d, "open": o, "high": h, "low": l,
                         "close": c, "volume": vol})
    if not bars:
        return None
    bars.sort(key=lambda x: x["date"])
    return bars



# 新浪接口返回中文列名，必须映射成英文
_COL_MAP = {"日期": "date", "开盘价": "open", "最高价": "high",
            "最低价": "low", "收盘价": "close", "成交量": "volume"}


LAST_FETCH_ERROR = ""


def fetch(sym):
    """用 akshare 拉新浪主连日线并更新本地 CSV。失败返回 None，
    失败原因写入模块级 LAST_FETCH_ERROR（供 refresh 打印）。

    【必须防「数据源抽风」】直接覆盖 CSV 是危险的：
    数据源某天只返回近 3 个月，本地 14 年历史就被冲掉了，
    而 carry 需要 252 根才出信号 —— 策略会静默变成全程空仓。
    所以覆盖前先做完整性校验，不通过就保留旧文件、当次按失败处理，
    并把旧文件备份成 .bak 以便人工恢复。
    """
    global LAST_FETCH_ERROR
    LAST_FETCH_ERROR = ""
    try:
        import akshare as ak
    except ImportError:
        LAST_FETCH_ERROR = "未安装 akshare（pip install akshare）"
        return None
    try:
        df = ak.futures_main_sina(symbol=sym + "0")
    except Exception as e:
        LAST_FETCH_ERROR = "%s: %s" % (type(e).__name__, e)
        return None
    if df is None or len(df) == 0:
        LAST_FETCH_ERROR = "返回空表"
        return None
    df = df.rename(columns=_COL_MAP)
    cols = ["date", "open", "high", "low", "close", "volume"]
    if not all(c in df.columns for c in cols):
        LAST_FETCH_ERROR = "列名不符：%s" % list(df.columns)
        return None
    # 列名对不代表列里是数字。新浪偶发把 '-' / 'None' 写进数值列，
    # astype(float) 会抛 ValueError。这里用 errors="coerce" 转成 NaN 再 dropna，
    # 整段包 try：数据解析失败宁可保留旧文件，也绝不能让定时任务崩在早上 8 点。
    try:
        df = df[cols].dropna()
        for c in cols[1:]:
            df[c] = df[c].astype(float)
        df = df[(df[cols[1:]] > 0).all(axis=1)]
    except Exception as e:
        LAST_FETCH_ERROR = "数据解析失败：%s: %s" % (type(e).__name__, e)
        return None
    if len(df) == 0:
        LAST_FETCH_ERROR = "清洗后无有效数据"
        return None

    path = os.path.join(DATA, sym + ".csv")
    old = read_csv(sym)
    new_bars = [{"date": str(r[0]), "open": float(r[1]), "high": float(r[2]),
                 "low": float(r[3]), "close": float(r[4]), "volume": float(r[5])}
                for r in df.itertuples(index=False, name=None)]
    new_bars.sort(key=lambda x: x["date"])

    # ── 用「合并」而不是「覆盖」──
    # 覆盖模式的教训（2026-10-20 定时任务实测）：akshare 返回的主连比本地少 5 个
    # 交易日（数据源自己丢了一段），覆盖后 14 年历史被截断，回测收益从 19.1%
    # 掉到 18.8%，而且不报错。少 5 行只占 0.16%，任何百分比阈值都拦不住。
    # 合并模式从根上解决：本地每个日期都必须保留，新数据只覆盖同日期、追加新日期，
    # 历史只增不减。代价是数据源删掉某天时本地仍留着 —— 但主连历史是既成事实，
    # 不会消失，留着比丢了安全得多。
    merged = {}
    for b in (old or []):
        merged[b["date"]] = b
    added = 0
    for b in new_bars:
        if b["date"] not in merged:
            added += 1
        merged[b["date"]] = b
    bars_out = [merged[k] for k in sorted(merged)]

    # 合并后仍比本地少 → 说明有日期对不上（格式差异等），拒绝写入
    if old and len(bars_out) < len(old):
        LAST_FETCH_ERROR = ("合并后 %d 根少于本地 %d 根，已保留本地数据"
                            % (len(bars_out), len(old)))
        return None

    os.makedirs(DATA, exist_ok=True)
    if os.path.exists(path):
        try:
            shutil.copy2(path, path + ".bak")
        except Exception:
            pass                                   # 备份失败不阻断主流程
    with open(path, "w", encoding="utf-8") as f:
        f.write("date,open,high,low,close,volume" + chr(10))
        for b in bars_out:
            f.write("%s,%s,%s,%s,%s,%s%s" % (b["date"], b["open"], b["high"],
                                             b["low"], b["close"], b["volume"], chr(10)))
    return read_csv(sym)



def refresh(syms=None, verbose=True):
    """重新拉取所有在用品种的日线。返回 (成功数, 失败列表)。

    定时任务必须先跑这一步，否则脚本只会读本地旧 CSV，
    数据日期不变 → notify 永远认为「数据未更新」。
    """
    syms = syms or [s[0] for s in active_instruments()]
    ok, bad = 0, []
    for s in syms:
        b = fetch(s)
        if b:
            ok += 1
            if verbose:
                print("  %-4s %-6s 更新至 %s（%d 根）" % (s, NAME.get(s, s), b[-1]["date"], len(b)))
        else:
            bad.append(s)
            if verbose:
                print("  %-4s %-6s 拉取失败，沿用本地数据 —— %s"
                      % (s, NAME.get(s, s), LAST_FETCH_ERROR))
    return ok, bad


def clean(bars, tol=0.5):
    """修坏点：某日价格相对前后两日中位数偏离 >50% 视为脏数据，用中位数替换。"""
    n = len(bars)
    for i in range(1, n - 1):
        ref = (bars[i - 1]["close"] + bars[i + 1]["close"]) / 2.0
        if ref <= 0:
            continue
        for k in ("open", "high", "low", "close"):
            if abs(bars[i][k] / ref - 1.0) > tol:
                bars[i][k] = ref
    return bars


def load(sym):
    """清洗 + 比例复权。

    返回 (adj_bars, real_last_price, live_price)。每根 adj bar 上附带：
        "gap"   —— 该日的【换月跳空】（非换月日为 0），供 carry 信号使用
        "scale" —— 复权累计因子；真实价 = 复权价 / scale
    复权的作用：把换月跳空抹掉，使价格序列的涨跌幅 = 真实持仓盈亏。

    【只保留已收盘的交易日】一个交易日要到 15:00 日盘收盘才算走完。
    若数据源已经给出"今天"那根 K 线（它只含前一晚夜盘、还没走完），
    拿它算信号会出错，所以这里直接剔除，只把它当"最新价"用。
    早盘 08:00 那次运行就靠这个护栏保证信号不会算错。
    """
    raw = read_csv(sym) or fetch(sym)
    if raw is None:
        return None, None, None
    raw = clean(raw)

    # 剔除当天还没走完的那根 K 线，只留作最新价
    live = None
    if raw and raw[-1]["date"] == time.strftime("%Y-%m-%d") and time.localtime().tm_hour < 15:
        live = raw[-1]["close"]
        raw = raw[:-1]
    if not raw:
        return None, None, None

    real_last = raw[-1]["close"]
    if live is None:
        live = real_last

    for i in range(1, len(raw)):
        pc, op = raw[i - 1]["close"], raw[i]["open"]
        raw[i]["gap"] = (op / pc - 1.0) if (pc > 0 and abs(op / pc - 1.0) > GAP_THRESH) else 0.0
    raw[0]["gap"] = 0.0

    out = [dict(raw[0])]
    out[0]["scale"] = 1.0
    k = 1.0
    for i in range(1, len(raw)):
        pc, op = raw[i - 1]["close"], raw[i]["open"]
        if pc > 0 and op > 0 and abs(op / pc - 1.0) > GAP_THRESH:
            k *= pc / op
        b = dict(raw[i])
        for c in ("open", "high", "low", "close"):
            b[c] = raw[i][c] * k
        b["scale"] = k
        out.append(b)
    return out, real_last, live


# ══════════════════════════════════════════════════════ 指标层
def ema(v, n):
    out, a, prev = [], 2.0 / (n + 1), None
    for x in v:
        prev = x if prev is None else a * x + (1 - a) * prev
        out.append(prev)
    return out


def atr(bars, n=ATR_N):
    """Wilder ATR（基于复权价，与收盘价的比值是尺度无关的）。"""
    out, prev = [], None
    for i, b in enumerate(bars):
        tr = (b["high"] - b["low"]) if i == 0 else max(
            b["high"] - b["low"], abs(b["high"] - bars[i - 1]["close"]),
            abs(b["low"] - bars[i - 1]["close"]))
        prev = tr if prev is None else (prev * (n - 1) + tr) / n
        out.append(prev)
    return out


def real_px(bars, i):
    """第 i 根 K 线的真实价（复权价 / 累计因子）。"""
    return bars[i]["close"] / bars[i]["scale"]


# ══════════════════════════════════════════════════════ 信号层
def sig_carry(bars, win=CARRY_WIN, thresh=CARRY_THR):
    """展期收益：滚动累计换月跳空的方向。累计正跳空 = 长期升水 = 做空。"""
    out = []
    for i in range(len(bars)):
        if i < win:
            out.append(0)
            continue
        s = sum(bars[j].get("gap", 0.0) for j in range(i - win + 1, i + 1))
        out.append(1 if s < -thresh else (-1 if s > thresh else 0))
    return out


def sig_trend(bars, fast=MA_FAST, slow=MA_SLOW):
    """双均线趋势：EMA20 > EMA60 → 1，否则 -1。"""
    c = [b["close"] for b in bars]
    ef, es = ema(c, fast), ema(c, slow)
    return [0 if i < slow else (1 if ef[i] > es[i] else -1) for i in range(len(bars))]


def signal(bars):
    """carry 与趋势同向才持仓（两条腿都要同意）。"""
    a, t = sig_carry(bars), sig_trend(bars)
    return [a[i] if a[i] == t[i] else 0 for i in range(len(bars))]


def exposure_at(bars, A, i):
    """bar i 的敞口 = min(cap, vol_target / 日波动率)，日波动率取 bar i-1 的 ATR/收盘。"""
    if i <= 0:
        return 1.0
    pc = bars[i - 1]["close"]
    dvol = A[i - 1] / pc if pc > 0 else 0.0
    return 1.0 if dvol < 1e-6 else min(EXPO_CAP, VOL_TARGET / dvol)


# ══════════════════════════════════════════════════════ 仓位计算
def plan(equity=None, verbose=False):
    """算出「今天收盘后」每个品种的目标仓位。返回 (rows, skipped, data_date)。

    手数分配（关键）：
      每个品种的目标名义 = 敞口 × (权益 / 同时持仓的品种数)
      —— 除以 N 是因为组合是等权平均的：N 个品种各占 1/N 资金。
         若每腿都按【全额权益】定仓，品种越多总杠杆越大，风险失控。
      然后向下取整到手；目标不足 MIN_FILL 手就不开（1 手会远超风险目标）。
    """
    eq = EQUITY if equity is None else equity
    cand, skipped, dates = [], [], []
    for sym, mult, mrate in active_instruments(eq):
        bars, _c, px = load(sym)
        if bars is None:
            skipped.append({"sym": sym, "name": NAME.get(sym, sym), "why": "无数据"})
            continue
        dates.append(bars[-1]["date"])
        # 只有 1 根 K 线时 WARMUP 都过不了，直接跳过 —— 否则下面
        # bars[last-1] 会变成 bars[-1]（负索引）取到同一根，指标全是废值。
        if len(bars) < st_min_bars():
            skipped.append({"sym": sym, "name": NAME.get(sym, sym),
                            "why": "仅 %d 根 K 线，不足 %d 根预热" % (len(bars), st_min_bars())})
            continue
        A = atr(bars)
        last = len(bars) - 1
        cur = signal(bars)[last]
        expo = exposure_at(bars, A, last)
        dvol = A[last - 1] / bars[last - 1]["close"]
        gap = sum(b.get("gap", 0.0) for b in bars[-CARRY_WIN:])
        lot_notional = px * mult
        margin_per = lot_notional * (mrate + BROKER_ADD)

        if lot_notional > eq * MAX_LEG_LEVERAGE:
            skipped.append({"sym": sym, "name": NAME.get(sym, sym), "why":
                            "1 手名义 %s 元 = %.1f 倍权益，超过 %.1f 倍杠杆上限"
                            % (format(lot_notional, ",.0f"), lot_notional / eq, MAX_LEG_LEVERAGE)})
            continue

        cand.append({
            "sym": sym, "name": NAME.get(sym, sym), "sig": cur, "px": px,
            "atr": dvol * px, "dvol": dvol, "expo": expo,
            "mult": mult, "mrate": mrate, "lot_notional": lot_notional,
            "margin_per": margin_per, "gap": gap, "date": bars[-1]["date"],
        })

    # 同时持仓数 = 有信号的品种数（至少 1）——组合按等权 1/N 分配资金
    n_sig = max(1, sum(1 for c in cand if c["sig"] != 0))
    share = eq / n_sig

    rows = []
    for c in cand:
        if c["sig"] == 0:                       # ← 空仓品种必须 0 手
            c["want"] = 0.0
            c["lots"] = 0
        elif LOTS_MODE == "fixed":
            c["want"] = c["expo"] * share / c["lot_notional"]
            c["lots"] = LOTS_PER_LEG
        else:
            c["want"] = c["expo"] * share / c["lot_notional"]
            c["lots"] = int(c["want"])
            if c["lots"] == 0 and c["want"] >= MIN_FILL and \
                    c["margin_per"] <= eq * MARGIN_SAFE:
                c["lots"] = 1                   # 不足 1 手但目标够接近，按 1 手执行
        c["notional"] = c["lots"] * c["lot_notional"]
        c["margin"] = c["lots"] * c["margin_per"]
        rows.append(c)

    # 总保证金预算：超了先砍【目标最小】的（它们被 1 手取整扭曲得最厉害）
    # 抽成共享函数：回测 backtest() 以前没走这段，导致回测收益系统性高于实盘可执行水平。
    if LOTS_MODE != "fixed":
        _fit_margin_budget(rows, eq)

    # ── 数据日期口径：取【所有参与品种都齐备的最新日期】──
    # 以前取 max(dates)，实测踩过坑（2026-10-21）：FG 更新到 10-21、HC 拉取失败
    # 仍停在 10-20，max 取 10-21 → FG 用 10-21 的信号、HC 用 10-20 的信号，
    # n_sig/share 按混合口径分钱，浮盈也把 HC 的陈旧价标成最新日期的账。
    # 落后太多（>STALE_DAYS 个自然日）的品种直接剔除，不让它拖累全体。
    if dates:
        newest = max(dates)
        kept = []
        for c in cand:
            gap = _days_between(c["date"], newest)
            if gap > STALE_DAYS:
                skipped.append({"sym": c["sym"], "name": NAME.get(c["sym"], c["sym"]),
                                "why": "数据截止 %s，落后最新日期 %d 天，本期不参与"
                                       % (c["date"], gap)})
            else:
                kept.append(c)
        rows = [r for r in rows if r["sym"] in {c["sym"] for c in kept}]
        dates = [c["date"] for c in kept]
    data_date = min(dates) if dates else None
    if verbose:
        for s in skipped:
            print("  跳过 %s(%s)：%s" % (s["name"], s["sym"], s["why"]))
        if dates and len(set(dates)) > 1:
            print("  ⚠ 各品种数据日期不一致（%s），已按最早的 %s 出信号"
                  % ("/".join(sorted(set(dates))), data_date))
    return rows, skipped, data_date


def _days_between(a, b):
    """两个 YYYY-MM-DD 之间相差几个自然日；解析不了返回 0（当作不落后）。"""
    try:
        import datetime as _dt
        da = _dt.datetime.strptime(a[:10], "%Y-%m-%d")
        db = _dt.datetime.strptime(b[:10], "%Y-%m-%d")
        return abs((da - db).days)
    except Exception:
        return 0


def _fit_margin_budget(rows, eq):
    """把持仓压到保证金预算内。plan() 与 backtest() 共用，保证两边口径一致。

    以前 backtest() 没走这段：回测能开出实盘开不起的仓位，收益被系统性高估。
    rows 里每项至少要有 lots / lot_notional / margin_per / want；
    margin 与 notional 缺失时按 lots × 单价现算（backtest 的临时结构走这条）。
    """
    for r in rows:
        if "margin" not in r or "notional" not in r:
            r["margin"] = r["lots"] * r["margin_per"]
            r["notional"] = r["lots"] * r["lot_notional"]
    budget = eq * MARGIN_BUDGET
    total = sum(r["margin"] for r in rows)
    for r in sorted([x for x in rows if x["lots"] > 0], key=lambda x: x["want"]):
        if total <= budget:
            break
        while total > budget and r["lots"] > 0:
            r["lots"] -= 1
            r["notional"] = r["lots"] * r["lot_notional"]
            r["margin"] = r["lots"] * r["margin_per"]
            total -= r["margin_per"]


def dir_txt(v):
    return {1: "多", -1: "空", 0: "空仓"}[v]


def _ym(d):
    """把日期字符串转成「年×12+月」用于比较起点；非标准格式返回 None。"""
    try:
        return int(d[:4]) * 12 + int(d[5:7])
    except (TypeError, ValueError, IndexError):
        return None


def st_min_bars():
    """plan() 要求的最少 K 线数：至少要能算出 ATR20 与 EMA60。"""
    return max(WARMUP, ATR_N, MA_SLOW) + 2


# ══════════════════════════════════════════════════════ 实盘信号
def show_signal():
    print("═" * 78)
    print("  实盘信号（T 日收盘生成，T+1 日开盘执行）")
    print("  账户权益 %s 元   单品种波动率目标 %.1f%%   敞口上限 %.1fx"
          % (format(EQUITY, ",.0f"), VOL_TARGET * 100, EXPO_CAP))
    print("═" * 78)
    print()
    rows, skipped, data_date = plan(verbose=True)
    for s in skipped:
        print("  %s(%s)  %s\n" % (s["name"], s["sym"], s["why"]))

    for r in rows:
        arrow = {1: "▲ 做多", -1: "▼ 做空", 0: "— 空仓"}[r["sig"]]
        if r["gap"] > CARRY_THR:
            basis = "长期升水（contango），做空收展期收益"
        elif r["gap"] < -CARRY_THR:
            basis = "长期贴水（backwardation），做多收展期收益"
        else:
            basis = "无明显展期结构 → 空仓"
        print("  %s(%s)  %s" % (r["name"], r["sym"], arrow))
        print("     现价 %.1f   20日ATR %.1f（真实口径）   日波动 %.2f%%   波动率敞口 %.2fx"
              % (r["px"], r["atr"], r["dvol"] * 100, r["expo"]))
        print("     近 252 日累计换月跳空 %+.2f%%  →  %s" % (r["gap"] * 100, basis))
        if r["sig"] == 0:
            print("     → 目标手数 0 手（不开仓）")
        else:
            print("     → 目标手数 %d 手（理论 %.2f 手）   名义 %s 元   保证金 %s 元"
                  % (r["lots"], r["want"], format(r["notional"], ",.0f"),
                     format(r["margin"], ",.0f")))
        print()

    tn = sum(r["notional"] for r in rows)
    tm = sum(r["margin"] for r in rows)
    print("  ── 合计 ──")
    print("     名义敞口 %s 元  =  %.2f 倍权益" % (format(tn, ",.0f"), tn / EQUITY))
    print("     占用保证金 %s 元  =  %.1f%% 权益（剩余 %s 元）"
          % (format(tm, ",.0f"), tm / EQUITY * 100, format(EQUITY - tm, ",.0f")))
    if tn > 0:
        worst = tn * 0.08
        print("     极端情形（全部同时反向 8%%，接近跌停）亏损约 %s 元 = %.1f%% 权益"
              % (format(worst, ",.0f"), worst / EQUITY * 100))

    if rows:
        print("\n  ── 最近 15 个交易日的信号 ──")
        # 必须按【日期】对齐，不能按索引：FG 从 2012 年就有数据、HC 从 2014 年
        # 才开始，两者差约 300 根。按索引对齐会让 FG 列显示一年前的信号，
        # 却标着 HC 的日期 —— 用户会据此判断错信号时序。
        ser, all_dates = {}, set()
        for r in rows:
            b, _c, _l = load(r["sym"])
            if not b:
                continue
            ser[r["sym"]] = {x["date"]: s for x, s in zip(b, signal(b))}
            all_dates |= {x["date"] for x in b}
        common = sorted(all_dates)
        print("  %-12s" % "日期" + "".join("  %-8s" % (NAME.get(s, s) + " " + s) for s in ser))
        for d in common[-15:]:
            print("  %-12s" % d + "".join(
                "  %-8s" % dir_txt(ser[s].get(d, 0)) for s in ser))
    print("\n  数据截止 %s" % data_date)
    print()


# ══════════════════════════════════════════════════════ 邮件
def send_mail(subject, text, html=None, cfg=None):
    """发邮件，失败重试 cfg['max_retries'] 次。返回 (ok, msg)。"""
    cfg = cfg or MAIL
    if not cfg.get("enabled", True):
        return False, "邮件未启用（MAIL['enabled'] = False）"

    msg = MIMEMultipart("alternative")
    msg["From"] = formataddr((str(Header("期货信号机器人", "utf-8")), cfg["from"]))
    msg["To"] = cfg["to"]
    msg["Subject"] = Header(subject, "utf-8")
    msg["Date"] = formatdate(localtime=True)
    msg.attach(MIMEText(text, "plain", "utf-8"))
    if html:
        msg.attach(MIMEText(html, "html", "utf-8"))

    rcpts = [x.strip() for x in cfg["to"].split(",") if x.strip()]
    err = None
    for attempt in range(1, int(cfg.get("max_retries", 3)) + 1):
        try:
            # local_hostname 必须显式给 ASCII 值：本机主机名可能含中文，
            # 默认值会让 EHLO 命令编码失败（UnicodeEncodeError: 'ascii' codec）。
            s = smtplib.SMTP_SSL(cfg["server"], int(cfg["port"]),
                                 local_hostname="localhost", timeout=25)
            s.login(cfg["from"], cfg["password"])
            s.sendmail(cfg["from"], rcpts, msg.as_string())
            s.quit()
            return True, "已发送（第 %d 次尝试）" % attempt
        except Exception as e:
            err = e
            if attempt < int(cfg.get("max_retries", 3)):
                time.sleep(2 * attempt)
    return False, "%s: %s" % (type(err).__name__, err)


def _load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_state(st):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False, indent=1)


def _pos_norm(v):
    """把 state 里的一条仓位记录统一成 dict。

    旧版只存方向（0 / ±1），没有手数和成本 —— lots=None 表示"手数未知"，
    用于区分「真的加减仓」和「旧记录缺字段」，避免升级后误报一次变动。

    容错：state 是人手可改的 JSON，也可能是更早版本写的。任何无法解析的值
    一律兜底成「空仓」(dir=0)，绝不能让一个坏字段把整个 notify 打崩 ——
    定时任务崩了不会重试，当天邮件就没了。
    """
    def _num(x):
        try:
            f = float(x)
            return f if f == f else 0.0        # 顺带挡掉 NaN
        except (TypeError, ValueError):
            return 0.0

    if isinstance(v, dict):
        d = int(_num(v.get("dir", 0)) or 0)
        d = 1 if d > 0 else (-1 if d < 0 else 0)
        lots = v.get("lots")
        ent = _num(v.get("entry_px") or 0.0)
        return {"dir": d,
                "lots": (int(_num(lots)) if lots is not None else None),
                "entry_px": (ent if ent > 0 else None),
                "entry_date": v.get("entry_date")}
    d = int(_num(v) or 0)
    return {"dir": (1 if d > 0 else (-1 if d < 0 else 0)),
            "lots": None, "entry_px": None, "entry_date": None}


def _rebuild_entry(sym, direction):
    """从信号历史倒推开仓价：最后一次信号翻成 direction 那天的收盘真实价。

    只用于把旧版 state（只有方向、没有成本）迁移成带成本的记录。

    【必须校验方向】如果信号历史里根本没有 direction（state 与信号对不上），
    倒推循环会把 i 停在最后一根，于是把【今天收盘价】当成开仓价返回 ——
    浮盈恒为 0，用户完全看不出账目是错的。此时宁可返回 None 让上层兜底。
    """
    bars, _c, _l = load(sym)
    if bars is None:
        return None
    sg = signal(bars)
    if sg[-1] != direction:
        return None                       # 当前信号与该方向不符，倒推无意义
    i = len(sg) - 1
    while i > WARMUP and sg[i] == direction:
        i -= 1
    j = min(i + 1, len(bars) - 1)
    return real_px(bars, j), bars[j]["date"]


def _load_positions(st):
    """读上次记录的仓位，并把旧格式补全成 {sym: {dir, lots, entry_px, entry_date}}。

    positions 本身不是 dict（手改坏了）时整体忽略，返回空 dict ——
    宁可当成「没有旧仓位」重新开始，也不能让定时任务崩在早上 8 点。
    """
    out = {}
    pos = st.get("positions")
    if not isinstance(pos, dict):
        return out
    for sym, v in pos.items():
        p = _pos_norm(v)
        if p["dir"] != 0 and p["entry_px"] is None:
            rb = _rebuild_entry(sym, p["dir"])
            if rb:
                p["entry_px"], p["entry_date"] = rb
        out[sym] = p
    return out


def _num_state(st, key, default=0.0):
    """安全读取 state 里的数值字段。手改坏成字符串时返回默认值。"""
    try:
        f = float(st.get(key) or 0.0)
        return f if f == f else default
    except (TypeError, ValueError):
        return default


def _track(rows, st, data_date):
    """比对「今日目标仓位」与「上次记录」，更新开仓成本并结算盈亏。

    返回 (positions, changes, pnl, realized_delta)：
      positions      —— 新的仓位记录（含开仓价，供下次比对）
      changes        —— 真正发生变动的品种（开仓/平仓/反手/加减仓）
      pnl            —— 当前持仓的浮动盈亏明细
      realized_delta —— 本次平仓/减仓兑现的盈亏（元）
    """
    old = _load_positions(st)
    new, changes, pnl = {}, [], []
    realized = 0.0

    for r in rows:
        sym, mult, px = r["sym"], r["mult"], r["px"]
        ndir = r["sig"] if r["lots"] > 0 else 0
        nlot = r["lots"] if ndir else 0
        rth = 0.0                      # 本品种本次兑现的盈亏（单独记，供邮件展示）

        o = old.get(sym) or {"dir": 0, "lots": 0, "entry_px": None, "entry_date": None}
        odir, oent, odat = o["dir"], o["entry_px"], o["entry_date"]
        lots_known = o["lots"] is not None
        olot = o["lots"] if lots_known else nlot

        # ── 开仓成本维护 ───────────────────────────────────────────
        # 手数未知的旧记录：olot 取 nlot 只是为了让「变动判定」不误报，
        # 但它不能参与盈亏结算 —— 否则反手时会用「新仓手数」去乘旧仓价差，
        # 凭空造出一笔已实现盈亏。lots_known=False 时一律跳过 realized。
        if ndir == 0:
            ent, edat = None, None
            if odir and oent is not None and lots_known:
                rth = (px - oent) * odir * olot * mult                  # 平仓兑现
                realized += rth
        elif odir != ndir:
            if odir and oent is not None and lots_known:              # 反手先平旧仓
                rth = (px - oent) * odir * olot * mult
                realized += rth
            ent, edat = px, data_date
        elif oent is None:                                             # 旧记录缺成本
            ent, edat = _rebuild_entry(sym, ndir) or (px, data_date)
        elif nlot > olot:                                              # 加仓 → 加权平均
            ent = (oent * olot + px * (nlot - olot)) / nlot
            edat = odat
        elif nlot < olot:                                              # 减仓 → 成本不变
            ent, edat = oent, odat
            if lots_known:
                rth = (px - oent) * ndir * (olot - nlot) * mult
                realized += rth
        else:
            ent, edat = oent, odat

        if ndir:
            new[sym] = {"dir": ndir, "lots": nlot, "entry_px": ent, "entry_date": edat}

        # ── 变动判定（旧记录手数未知时不算变动，只补全）───────────
        if ndir == odir and (not lots_known or nlot == olot):
            pass
        else:
            # 【下单指令必须精确到「几笔、每笔多少手」】
            # 以前只给一个最终手数，实测会误导：
            #   平仓显示「0 手」（其实要平 1 手）
            #   反手显示「1 手」（其实要先平 1 手再开 1 手，两笔）
            #   加仓显示「2 手」（其实只加 1 手，看到 2 手会开成 3 手）
            # 这里按变动类型拆成明确的操作清单。
            open_txt = "开%s" % ("多" if ndir > 0 else "空")
            # margin_released = 本次平掉/减掉的手数所释放的保证金。
            # 平仓时 r["margin"] 是目标持仓（0），不能拿它当释放额 —— 会显示「释放 0」。
            if ndir == 0:
                legs = [("平%s" % dir_txt(odir), olot)]
                margin_after = 0.0
                margin_released = olot * r["margin_per"]
            elif odir == 0:
                legs = [(open_txt, nlot)]
                margin_after = r["margin"]
                margin_released = 0.0
            elif ndir == -odir:
                legs = [("平%s" % dir_txt(odir), olot), (open_txt, nlot)]
                margin_after = r["margin"]
                margin_released = olot * r["margin_per"]
            elif nlot > olot:
                legs = [("加%s" % dir_txt(ndir), nlot - olot)]
                margin_after = r["margin"]
                margin_released = 0.0
            else:
                legs = [("减%s" % dir_txt(ndir), olot - nlot)]
                margin_after = r["margin"]
                margin_released = (olot - nlot) * r["margin_per"]

            if len(legs) == 1:
                how = "%s %d 手" % legs[0]
                if ndir != 0 and ndir == odir:
                    how += "（至 %d 手）" % nlot
            else:
                how = "先%s %d 手 → 再%s %d 手" % (
                    legs[0][0], legs[0][1], legs[1][0], legs[1][1])

            if r["gap"] > CARRY_THR:
                basis = "长期升水（contango），做空收展期收益"
            elif r["gap"] < -CARRY_THR:
                basis = "长期贴水（backwardation），做多收展期收益"
            else:
                basis = "无明显展期结构"

            if ndir == 0:
                reason = "carry 与趋势不再同向（或信号消失）"
            elif odir == 0:
                reason = ("近 252 日累计换月跳空 %+.2f%% 为%s，且 EMA20/60 趋势同向"
                          % (r["gap"] * 100, "正（长期升水）" if r["gap"] > 0 else "负（长期贴水）"))
            else:
                reason = "carry 与趋势同时反向"

            c = dict(r)
            c.update({"how": how, "reason": reason, "basis": basis,
                      "legs": legs, "n_orders": len(legs),
                      "order_lots": sum(x[1] for x in legs),
                      "margin_after": margin_after,
                      "margin_released": margin_released,
                      "realized_this": rth})
            changes.append(c)

        # ── 浮动盈亏 ──────────────────────────────────────────────
        if ndir and ent is not None:
            amt = (px - ent) * ndir * nlot * mult
            base = ent * mult * nlot
            pnl.append({"sym": sym, "name": r["name"], "dir": ndir, "lots": nlot,
                        "entry": ent, "entry_date": edat, "px": px, "mult": mult,
                        "amt": amt, "pct": (amt / base if base else 0.0)})

    return new, changes, pnl, realized


# ── 邮件样式（全部内联：邮件客户端不认 <style> 标签）──────────────
_C_TH = ("padding:8px 5px;background:#eef1f5;border-bottom:2px solid #d5dbe3;"
         "font-size:12.5px;color:#4a5460;font-weight:700;text-align:left")
_C_TD = "padding:9px 5px;border-bottom:1px solid #eceff3;font-size:14px;color:#1c2128;word-break:break-word"
_C_NUM = _C_TD + ";text-align:right"
_COLOR = {1: "#c62828", -1: "#2e7d32", 0: "#98a2ad"}      # 红涨绿跌

# 盈亏表列多（6 列），用更紧凑的字号，保证 390px 手机屏不折行
_C_TH2 = ("padding:7px 3px;background:#eef1f5;border-bottom:2px solid #d5dbe3;"
          "font-size:11.5px;color:#4a5460;font-weight:700;text-align:left")
_C_TD2 = "padding:7px 3px;border-bottom:1px solid #eceff3;font-size:12.5px;color:#1c2128;word-break:break-word"
_C_NUM2 = _C_TD2 + ";text-align:right"


def _tbl(headers, widths, rows, note_rows=None, dense=False, right=None):
    """生成手机友好的 HTML 表格。

    用 table-layout:fixed + colgroup 固定列宽 —— 否则手机窄屏下表会撑破容器、
    最右一列被截掉。note_rows = {行号: 说明文字}，跨列显示在该行下方。
    dense=True 用更小的表头字号（列多的盈亏表用）；
    right = 需要右对齐的列下标集合（数值列，跟数据行对齐）。
    """
    note_rows = note_rows or {}
    right = right or ()
    th = _C_TH2 if dense else _C_TH
    cols = "".join('<col style="width:' + w + '">' for w in widths)
    h = ('<table style="width:100%;max-width:100%;border-collapse:collapse;'
         'table-layout:fixed;margin:6px 0 2px" cellpadding="0" cellspacing="0">'
         '<colgroup>' + cols + '</colgroup>')
    h += "<tr>" + "".join(
        '<th style="%s%s">%s</th>' % (th, ";text-align:right" if i in right else "", x)
        for i, x in enumerate(headers)) + "</tr>"
    for i, cells in enumerate(rows):
        h += "<tr>" + "".join(cells) + "</tr>"
        if i in note_rows:
            h += ('<tr><td colspan="%d" style="padding:0 5px 10px;font-size:12px;'
                  'color:#67717c;line-height:1.6;border-bottom:1px solid #eceff3;'
                  'word-break:break-word">%s</td></tr>' % (len(headers), note_rows[i]))
    return h + "</table>"


def _money(x):
    """带符号的金额文本（元），用于邮件正文。"""
    if abs(x) < 0.5:
        return "0"
    return ("+" if x > 0 else "-") + format(abs(x), ",.0f")


def _build_mail(rows, changes, data_date, positions=None, pnl=None,
                realized=0.0, start_equity=None, start_date=None, first=False):
    """组装邮件标题 + 正文（HTML 表格，手机可读）。

    · 有仓位变动 → 标题高亮「⚠ 有变更」，正文顶部先列操作清单
    · 无仓位变动 → 标题直接报当前浮盈/浮亏，正文列持仓与盈亏明细
    """
    pnl = pnl or []
    md = data_date[5:] if data_date and len(data_date) >= 10 else (data_date or "")
    tot_pnl = sum(x["amt"] for x in pnl)

    # ── 标题：有变动重点提醒，无变动直接报盈亏 ──────────────────
    if first:
        subject = "【期货信号·基线】%s  初始持仓 %d 项" % (md, len(pnl))
    elif changes:
        parts = ["%s %s" % (c["name"], c["how"]) for c in changes]
        subject = "【⚠ 期货信号·有变更】%s  %s" % (md, " / ".join(parts))
    elif pnl:
        subject = "【期货信号·持仓】%s  %s %s 元" % (
            md, "浮盈" if tot_pnl >= 0 else "浮亏", format(abs(tot_pnl), ",.0f"))
    else:
        subject = "【期货信号·持仓】%s  当前空仓" % md

    tn = sum(r["notional"] for r in rows)
    tm = sum(r["margin"] for r in rows)

    # ── ① 本次变动表 ──
    # 列：品种 / 操作 / 手数 / 参考价 / 变动后保证金
    # 「手数」用 order_lots（本次真正要下的手数），不是目标持仓手数 ——
    # 平仓时目标持仓是 0，直接用会显示「0 手」，用户不知道该平多少。
    ch_rows, ch_notes = [], {}
    for k, c in enumerate(changes):
        col = _COLOR[c["sig"]]
        n_ord = c.get("n_orders", 1)
        o_lots = c.get("order_lots", c["lots"])
        m_after = c.get("margin_after", c["margin"])
        if m_after <= 0:
            m_txt = "释放 %s" % format(c.get("margin_released", c["margin"]), ",.0f")
        else:
            m_txt = format(m_after, ",.0f")
        lots_txt = ("%d 手" % o_lots) if n_ord == 1 else ("%d 笔/%d 手" % (n_ord, o_lots))
        ch_rows.append([
            '<td style="%s"><b>%s</b> <span style="font-size:12px;color:#8a949e">%s</span></td>'
            % (_C_TD, c["name"], c["sym"]),
            '<td style="%s;color:%s;font-weight:700">%s</td>' % (_C_TD, col, c["how"]),
            '<td style="%s">%s</td>' % (_C_NUM, lots_txt),
            '<td style="%s">%s</td>' % (_C_NUM, format(c["px"], ",.1f")),
            '<td style="%s">%s</td>' % (_C_NUM, m_txt),
        ])
        note = "%s　·　日波动 %.2f%%　敞口 %.2fx" % (c["basis"], c["dvol"] * 100, c["expo"])
        if c.get("realized_this"):
            note += "　·　本次兑现 %s 元" % _money(c["realized_this"])
        ch_notes[k] = note
    ch_tbl = _tbl(["品种", "操作", "手数", "参考价", "保证金"],
                  ["28%", "18%", "12%", "20%", "22%"], ch_rows, ch_notes,
                  right=(2, 3, 4))

    # ── ② 持仓盈亏表（6 列，紧凑字号保证手机不折行）──
    pos_rows, pos_notes = [], {}
    for k, p in enumerate(pnl):
        col = _COLOR[p["dir"]]
        pcol = _COLOR[1] if p["amt"] >= 0 else _COLOR[-1]      # 红盈绿亏
        pos_rows.append([
            '<td style="%s"><b>%s</b> <span style="font-size:11px;color:#8a949e">%s</span></td>'
            % (_C_TD2, p["name"], p["sym"]),
            '<td style="%s;color:%s;font-weight:700">%s</td>' % (_C_TD2, col, dir_txt(p["dir"])),
            '<td style="%s">%d</td>' % (_C_NUM2, p["lots"]),
            '<td style="%s">%s</td>' % (_C_NUM2, format(p["entry"], ",.1f")),
            '<td style="%s">%s</td>' % (_C_NUM2, format(p["px"], ",.1f")),
            '<td style="%s;color:%s;font-weight:700">%s<br>'
            '<span style="font-size:11px;font-weight:400">%+.2f%%</span></td>'
            % (_C_NUM2, pcol, _money(p["amt"]), p["pct"] * 100),
        ])
        pos_notes[k] = "%s 建仓　·　名义 %s 元" % (
            p["entry_date"] or "—", format(p["px"] * p["lots"] * p["mult"], ",.0f"))
    if pos_rows:
        tcol = _COLOR[1] if tot_pnl >= 0 else _COLOR[-1]
        bt = ";border-top:2px solid #d5dbe3"
        pos_rows.append([
            '<td style="%s;font-weight:700%s">合计</td>' % (_C_TD2, bt),
            '<td style="%s%s"></td>' % (_C_TD2, bt),
            '<td style="%s;font-weight:700%s">%d</td>' % (_C_NUM2, bt, sum(p["lots"] for p in pnl)),
            '<td style="%s%s"></td>' % (_C_TD2, bt),
            '<td style="%s%s"></td>' % (_C_TD2, bt),
            '<td style="%s;color:%s;font-weight:700%s">%s</td>' % (_C_NUM2, tcol, bt, _money(tot_pnl)),
        ])
    else:
        pos_rows.append(['<td style="%s" colspan="6">当前无持仓（全部空仓）</td>' % _C_TD2])
    pos_tbl = _tbl(["品种", "方向", "手数", "开仓价", "现价", "浮动盈亏"],
                   ["23%", "11%", "11%", "17%", "17%", "21%"], pos_rows,
                   pos_notes, dense=True, right=(2, 3, 4, 5))

    # ── 组装 ──
    P = "margin:0 0 4px;font-size:15px;font-weight:700;color:#1c2128"
    S = "margin:0;font-size:13px;color:#67717c;line-height:1.7"
    h = ['<div style="font-family:-apple-system,BlinkMacSystemFont,\'PingFang SC\','
         '\'Microsoft YaHei\',sans-serif;font-size:15px;color:#1c2128;'
         'line-height:1.7;width:100%;max-width:600px;margin:0 auto;'
         'overflow-wrap:break-word;word-break:break-word">']

    bar_bg = "#b3261e" if changes else "#1c2128"          # 有变更 → 红色标题条
    tag = "⚠ 仓位有变更" if changes else "每日持仓简报"
    h.append('<div style="background:%s;color:#fff;padding:14px 16px;border-radius:8px">'
             '<div style="font-size:17px;font-weight:700">期货信号 · %s</div>'
             '<div style="font-size:13px;opacity:.85;margin-top:6px;line-height:1.6">'
             '数据截止 %s　·　权益 %s 元<br><b>下一交易日开盘执行</b></div></div>'
             % (bar_bg, tag, data_date, format(EQUITY, ",.0f")))

    if changes:
        total_orders = sum(c.get("n_orders", 1) for c in changes)
        h.append('<p style="%s;margin-top:18px">■ 本次需要操作（%d 项 / 共 %d 笔）</p>'
                 % (P, len(changes), total_orders))
        h.append(ch_tbl)
        # 下单要点：这几句是为了避免最常见的三种下错方式
        h.append('<p style="%s;margin-top:4px">'
                 '· 「参考价」是上一交易日收盘价，<b>不是限价</b>，开盘按市价成交即可<br>'
                 '· 标注「2 笔」的（反手）必须<b>先平旧仓、再开新仓</b>，顺序不能反<br>'
                 '· 平仓后保证金会释放，可以立刻用于同一封邮件里的其他开仓</p>' % S)
    else:
        h.append('<p style="%s;margin-top:18px">■ 本次无仓位变动</p>' % P)
        h.append('<p style="%s">持仓与上次一致，今天不需要下单。</p>' % S)

    h.append('<p style="%s;margin-top:20px">■ 当前持仓与盈亏</p>' % P)
    h.append(pos_tbl)

    if pnl:
        pcol = _COLOR[1] if tot_pnl >= 0 else _COLOR[-1]
        h.append('<p style="%s;margin-top:6px">持仓浮动盈亏 <b style="color:%s">%s 元</b>'
                 '　·　名义敞口 %.2f 倍权益　·　保证金占权益 %.1f%%</p>'
                 % (S, pcol, _money(tot_pnl), tn / EQUITY, tm / EQUITY * 100))
    else:
        h.append('<p style="%s;margin-top:6px">当前无持仓，名义敞口 0.00 倍权益。</p>' % S)

    if start_equity:
        cur_eq = start_equity + realized + tot_pnl
        d = cur_eq - start_equity
        dcol = _COLOR[1] if d >= 0 else _COLOR[-1]
        h.append('<p style="%s;margin-top:14px;padding:10px 12px;background:#f6f8fa;'
                 'border-radius:6px;line-height:1.8">跟踪权益 <b>%s</b> → '
                 '<b style="color:%s">%s</b> 元<br>'
                 '<span style="font-size:12px">累计 %s 元（%+.2f%%）　·　已实现 %s 元'
                 '　·　浮动 %s 元<br>自 %s 起按信号跟踪</span></p>'
                 % (S, format(start_equity, ",.0f"), dcol, format(cur_eq, ",.0f"),
                    _money(d), d / start_equity * 100, _money(realized),
                    _money(tot_pnl), start_date or "—"))

    idle = [r for r in rows if r["sig"] == 0]
    if idle:
        h.append('<p style="%s">空仓（无信号）：%s</p>'
                 % (S, "、".join("%s %s" % (r["name"], r["sym"]) for r in idle)))

    h.append('<p style="%s;margin-top:20px">■ 风险提示</p>' % P)
    h.append('<p style="%s">· 本策略不设止损，风险控制靠波动率目标仓位 + 杠杆护栏。<br>'
             '· 极端情形（全部持仓同时反向 8%%）约亏 %s 元 = %.1f%% 权益。<br>'
             '· 历史回测不代表未来表现；期货为保证金交易，存在本金全部损失的风险。</p>'
             % (S, format(tn * 0.08, ",.0f"), tn * 0.08 / EQUITY * 100))
    # 这两条是「下单环节」最容易出事的地方，必须写在邮件里：
    # ① 本脚本只发信号，不碰你的账户，也不知道你到底下没下单；
    # ② 期货只能整手下，目标 0.6 手会开成 1 手，实际敞口高于模型目标。
    h.append('<p style="%s;margin-top:10px;padding:10px 12px;background:#fff8e6;'
             'border-left:3px solid #e0a800;border-radius:4px">'
             '<b>下单须知</b><br>'
             '· 本邮件是<b>信号建议</b>，不连接你的账户，也无法确认你是否真的成交。'
             '若某次没下单，请以<b>账户实际持仓</b>为准，别以本邮件为准。<br>'
             '· 期货只能整手交易：目标手数会向下取整（不足 1 手但接近时按 1 手），'
             '所以<b>单腿实际敞口可能高于模型目标</b>，属正常现象。<br>'
             '· 开仓价按信号日收盘价估算，实际以你的成交价为准，'
             '因此「跟踪权益」与券商结算会有小差异。</p>' % S)
    h.append('<p style="%s;margin-top:16px;padding-top:10px;border-top:1px solid #eceff3">'
             '由 strategy_top2.py 自动发送</p>' % S)
    h.append("</div>")
    html = "".join(h)

    # ── 纯文本兜底（部分客户端不渲染 HTML）──
    L = ["期货信号 · 展期收益 + 趋势",
         "数据截止 %s   权益 %s 元   下一交易日开盘执行" % (data_date, format(EQUITY, ",.0f")),
         "-" * 46]
    if changes:
        L.append("本次需要操作（%d 项 / 共 %d 笔）"
                 % (len(changes), sum(c.get("n_orders", 1) for c in changes)))
        L.append("%-10s %-22s %6s %8s %10s" % ("品种", "操作", "手数", "参考价", "保证金"))
        for c in changes:
            n_ord = c.get("n_orders", 1)
            o_lots = c.get("order_lots", c["lots"])
            m_after = c.get("margin_after", c["margin"])
            m_txt = ("释放 %s" % format(c.get("margin_released", c["margin"]), ",.0f")) \
                if m_after <= 0 else format(m_after, ",.0f")
            lots_txt = ("%d手" % o_lots) if n_ord == 1 else ("%d笔/%d手" % (n_ord, o_lots))
            L.append("%-10s %-22s %6s %8s %10s"
                     % (c["name"], c["how"], lots_txt,
                        format(c["px"], ",.1f"), m_txt))
        L.append("参考价=上一交易日收盘价，不是限价；反手须先平后开。")
    else:
        L.append("本次无仓位变动，今天不需要下单。")
    L.append("")
    L.append("当前持仓与盈亏")
    L.append("%-12s %-4s %4s %9s %9s %10s"
             % ("品种", "方向", "手数", "开仓价", "现价", "浮动盈亏"))
    for p in pnl:
        L.append("%-12s %-4s %4d %9s %9s %10s"
                 % (p["name"], dir_txt(p["dir"]), p["lots"],
                    format(p["entry"], ",.1f"), format(p["px"], ",.1f"), _money(p["amt"])))
    if not pnl:
        L.append("（无持仓）")
    L.append("-" * 46)
    L.append("浮动盈亏合计 %s 元   名义 %.2f 倍权益   保证金占权益 %.1f%%"
             % (_money(tot_pnl), tn / EQUITY, tm / EQUITY * 100))
    if start_equity:
        cur_eq = start_equity + realized + tot_pnl
        L.append("跟踪权益 %s → %s 元（累计 %s 元）"
                 % (format(start_equity, ",.0f"), format(cur_eq, ",.0f"),
                    _money(cur_eq - start_equity)))
    L.append("")
    L.append("风险提示：不设止损；极端情形约亏 %.1f%% 权益；历史回测不代表未来表现。"
             % (tn * 0.08 / EQUITY * 100))
    L.append("-- 由 strategy_top2.py 自动发送")
    return subject, "\n".join(L), html


def notify(argv=None):
    """每个交易日推送邮件（早盘前、晚盘前各一次）。

    · 有仓位变动 → 标题高亮「⚠ 有变更」，正文顶部先列操作清单
    · 无仓位变动 → 标题直接报当前浮盈/浮亏，正文列持仓与盈亏明细

    参数： am       —— 早盘场次（08:00 跑）
          pm       —— 晚盘场次（20:00 跑）
          都不写时按当前小时自动判断：15 点前算 am，之后算 pm
          daily    —— 强制发送（该场次今天已发过也再发一封）
          nofetch  —— 跳过数据更新（用本地 CSV）
          test     —— 只把邮件内容打印出来，不真的发出去

    两场用不同的去重键（notified.am / notified.pm），所以同一天两场都会发；
    但同一场重复运行不会重复发。
    """
    argv = argv or []
    daily = "daily" in argv
    dry = "test" in argv
    if "am" in argv:
        slot = "am"
    elif "pm" in argv:
        slot = "pm"
    else:
        # 手动运行（没带 am/pm）时才自动判场次。
        # 定时任务的 bat 一律显式传 am/pm，不受这里影响。
        # 注意 15:00~20:00 会被判成 pm —— 这段是日盘已收、夜盘未开，
        # 数据与 20:00 那次几乎相同，若 20:00 那次也推过就会被去重挡下，
        # 反过来先跑 20:00 的则这次会被挡。想强制发就加 daily。
        slot = "am" if time.localtime().tm_hour < 15 else "pm"

    if "nofetch" not in argv:
        print("更新行情数据…")
        n_ok, bad = refresh(verbose=True)
        if bad:
            print("  注意：%d 个品种拉取失败，沿用本地数据" % len(bad))
        print()

    rows, skipped, data_date = plan()
    if data_date is None:
        print("没有可用数据，放弃")
        return

    st = _load_state()
    notified = dict(st.get("notified") or {})
    if notified.get(slot) == data_date and not daily:
        print("【%s 场次】数据仍为 %s，这一场已经推过了，跳过。"
              "想强制再发一封请加 daily。" % (slot, data_date))
        return

    # 权益基数变了（用户加/减本金）→ 跟踪基线重置，避免盈亏数字对不上
    # start_equity 可能被手改坏成字符串/None，统一走 _num_state 兜底
    start_equity = st.get("start_equity")
    se_num = _num_state(st, "start_equity", 0.0) if start_equity is not None else 0.0
    realized = _num_state(st, "realized", 0.0)
    start_date = st.get("start_date")
    if not start_equity or se_num <= 0 or abs(se_num - EQUITY) > 0.5:
        if start_equity and se_num > 0:
            print("权益基数由 %s 改为 %s 元，跟踪基线重置。"
                  % (format(se_num, ",.0f"), format(EQUITY, ",.0f")))
        start_equity, realized, start_date = EQUITY, 0.0, data_date
    else:
        start_equity = se_num

    newpos, changes, pnl, rdelta = _track(rows, st, data_date)
    realized += rdelta

    # 「首次建基线」只应由「从未有过持仓」触发。
    # 以前用 not st.get("positions")：全部平仓后 positions 为空字典，
    # 会被误判成首日，标题从「浮盈/浮亏」变成毫无信息量的「初始持仓 0 项」。
    first = not st.get("baseline_done")
    subject, text, html = _build_mail(rows, changes, data_date, newpos, pnl,
                                      realized, start_equity, start_date, first)

    if dry:
        print("【试运行，不发送】[%s 场次] %s" % (slot, subject))
        print()
        print(text)
        return

    ok, msg = send_mail(subject, text, html)
    print("[%s 场次] %s  →  %s" % (slot, subject, msg))
    if ok:
        notified[slot] = data_date
        _save_state({"data_date": data_date, "positions": newpos,
                     "realized": realized, "start_equity": start_equity,
                     "start_date": start_date, "notified": notified,
                     "baseline_done": True,
                     "updated": time.strftime("%Y-%m-%d %H:%M:%S")})
    else:
        print("邮件发送失败，状态未更新，下次运行会重试。")


# ══════════════════════════════════════════════════════ 回测
def backtest(verbose=True):
    """2 万实盘口径：LOTS_MODE 决定手数，信号驱动，T+1 开盘调仓。

    盈亏换算：持有 1 手的当日盈亏 = 乘数 × 真实前收 × 复权日收益。
    复权日收益已剔除换月跳空 —— 那个跳空不是你能拿到的钱。
    """
    S = {}
    for sym, mult, mrate in active_instruments():
        bars, _c, _l = load(sym)
        if bars is None:
            continue
        lot_notional = real_px(bars, len(bars) - 1) * mult
        if lot_notional > EQUITY * MAX_LEG_LEVERAGE:
            if verbose:
                print("  跳过 %s(%s)：1 手名义 %s 元 = %.1f 倍权益，超过 %.1f 倍杠杆上限"
                      % (NAME.get(sym, sym), sym, format(lot_notional, ",.0f"),
                         lot_notional / EQUITY, MAX_LEG_LEVERAGE))
            continue
        S[sym] = {"bars": bars, "sig": signal(bars), "atr": atr(bars),
                  "mult": mult, "mrate": mrate}
    if not S:
        print("无可用数据（或全部品种都超过杠杆上限）")
        return None

    base = min(S, key=lambda s: len(S[s]["bars"]))
    dates = [b["date"] for b in S[base]["bars"]]
    idx = {s: {b["date"]: i for i, b in enumerate(v["bars"])} for s, v in S.items()}

    eq = EQUITY
    curve, daily = [], []
    pos = {s: 0 for s in S}
    trades = {s: 0 for s in S}

    for t in range(1, len(dates)):
        dt = dates[t]
        # ① 本日各品种的目标方向（用 bar i-1 收盘确认的信号）
        tgt = {}
        for sym, v in S.items():
            i = idx[sym].get(dt)
            tgt[sym] = 0 if (i is None or i == 0 or (i - 1) < WARMUP) else v["sig"][i - 1]
        # ② 同时持仓数决定每腿资金份额（等权 1/N，与 plan() 同一口径）
        n_sig = max(1, sum(1 for x in tgt.values() if x != 0))
        share = eq / n_sig

        pnl = 0.0
        # 本日各品种的「计划持仓」：先按 plan() 同一公式算目标手数，
        # 再统一压到保证金预算内 —— 与 plan() 共用 _fit_margin_budget，
        # 否则回测会开出实盘开不起的手数，收益被系统性高估。
        calc = []
        for sym, v in S.items():
            i = idx[sym].get(dt)
            if i is None or i == 0:
                continue
            bars = v["bars"]
            if tgt[sym] == 0:
                lots = 0
                want = 0.0
            elif LOTS_MODE == "fixed":
                lots = LOTS_PER_LEG * tgt[sym]
                want = float(abs(lots))
            else:
                lot_notional = real_px(bars, i - 1) * v["mult"]
                want = exposure_at(bars, v["atr"], i - 1) * share / lot_notional
                n = int(want)
                if n == 0 and want >= MIN_FILL and \
                        lot_notional * (v["mrate"] + BROKER_ADD) <= eq * MARGIN_SAFE:
                    n = 1
                lots = n * tgt[sym]
            calc.append({"sym": sym, "v": v, "i": i, "bars": bars, "lots": lots,
                         "want": want,
                         "lot_notional": real_px(bars, i - 1) * v["mult"],
                         "margin_per": real_px(bars, i - 1) * v["mult"] * (v["mrate"] + BROKER_ADD)})
        if LOTS_MODE != "fixed":
            _fit_margin_budget(calc, eq)

        for c in calc:
            sym, v, i, bars, lots = c["sym"], c["v"], c["i"], c["bars"], c["lots"]
            if lots != pos[sym]:
                # 成本按【次日开盘】才是真实可成交价；这里用当日收盘近似，
                # 与 ft.py 的口径（开盘价）差一个隔夜跳空量级，属已知近似。
                pnl -= abs(lots - pos[sym]) * real_px(bars, i) * v["mult"] * (FEE + SLIP)
                if pos[sym] == 0 and lots != 0:
                    trades[sym] += 1
                pos[sym] = lots
            if pos[sym] != 0:
                r = bars[i]["close"] / bars[i - 1]["close"] - 1.0      # 复权日收益（已去跳空）
                pnl += pos[sym] * v["mult"] * real_px(bars, i - 1) * r
        eq += pnl
        curve.append(eq)
        prev_eq = curve[-2] if len(curve) > 1 else EQUITY
        daily.append(pnl / prev_eq if prev_eq > 0 else 0.0)
        if eq <= 0:
            if verbose:
                print("!! 权益归零，回测终止于 %s" % dt)
            break

    yrs = len(curve) / TRADING_DAYS
    cagr = (eq / EQUITY) ** (1 / yrs) - 1 if yrs > 0 and eq > 0 else -1.0
    peak, mdd = EQUITY, 0.0
    for v in curve:
        peak = max(peak, v)
        mdd = max(mdd, (peak - v) / peak)
    sd = statistics.pstdev(daily) if len(daily) > 1 else 0.0
    sharpe = statistics.mean(daily) / sd * math.sqrt(TRADING_DAYS) if sd > 1e-12 else 0.0

    if verbose:
        legs = " + ".join("%s(%s)" % (NAME.get(s, s), s) for s in S)
        print("═" * 78)
        print("  回测：%s   手数模式 %s   T+1 开盘调仓" % (legs, LOTS_MODE))
        print("  成本 %.0fbp 手续费 + %.0fbp 滑点   起始权益 %s 元"
              % (FEE * 1e4, SLIP * 1e4, format(EQUITY, ",.0f")))
        print("═" * 78)
        print("  区间      %s → %s  (%.1f 年)" % (dates[0], dates[-1], yrs))
        print("  期末权益  %s 元   倍数 %.2fx   年化 %.2f%%"
              % (format(eq, ",.0f"), eq / EQUITY, cagr * 100))
        print("  最大回撤  %.1f%%   Calmar %.2f   Sharpe %.2f"
              % (mdd * 100, (cagr / mdd) if mdd > 1e-9 else 0.0, sharpe))
        print("  开仓次数  " + "   ".join("%s %d 次" % (NAME.get(s, s), n) for s, n in trades.items()))
        print()

        print("  样本内外拆分（防止用后见之明挑品种）")
        for lab, lo, hi in [("样本内 ≤2018", "0000", "2018"), ("样本外 ≥2019", "2019", "9999")]:
            seg = [i for i, dt in enumerate(dates[:len(curve)]) if lo <= dt[:4] <= hi]
            if len(seg) < 60:
                continue
            b0 = EQUITY if seg[0] == 0 else curve[seg[0] - 1]
            b1 = curve[seg[-1]]
            y = (seg[-1] - seg[0] + 1) / TRADING_DAYS
            c2 = (b1 / b0) ** (1 / y) - 1 if y > 0 and b1 > 0 else -1.0
            pk, dd = b0, 0.0
            for i in seg:
                pk = max(pk, curve[i])
                dd = max(dd, (pk - curve[i]) / pk)
            print("    %-12s 年化 %6.2f%%   区间回撤 %5.1f%%   倍数 %.2fx"
                  % (lab, c2 * 100, dd * 100, b1 / b0))
        print()

        print("  年份       年末权益      年度收益")
        print("  " + "-" * 38)
        base_eq = EQUITY
        for i, dt in enumerate(dates[:len(curve)]):
            nxt = dates[i + 1][:4] if i + 1 < len(dates[:len(curve)]) else None
            if nxt != dt[:4]:
                print("  %-10s %11s   %+8.1f%%"
                      % (dt[:4], format(curve[i], ",.0f"), (curve[i] / base_eq - 1) * 100))
                base_eq = curve[i]
        print()

        if curve:
            print("  净值曲线（横轴为全区间）")
            step = max(1, len(curve) // 64)
            pts = curve[::step]
            lo, hi = min(pts + [EQUITY]), max(pts)
            for k in range(8, -1, -1):
                lv = lo + (hi - lo) * k / 8
                print("  %9s │" % format(lv, ",.0f") + "".join("█" if v >= lv else " " for v in pts))
            print("  " + " " * 10 + "└" + "─" * len(pts))
            print()

    return {"cagr": cagr, "mdd": mdd, "mult": eq / EQUITY, "sharpe": sharpe, "curve": curve}


# ══════════════════════════════════════════════════════ 入口
if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    if cmd in ("signal", "all"):
        show_signal()
    if cmd in ("backtest", "all"):
        backtest()
    if cmd == "notify":
        notify(sys.argv[2:])
    if cmd == "refresh":
        ok, bad = refresh()
        print("\n成功 %d 个%s" % (ok, "，失败：" + " ".join(bad) if bad else ""))
    if cmd == "test-mail":
        # 发两封【真实格式】的样例，让用户直接看到以后会收到长什么样：
        #   ① 有仓位变更（标题高亮）  ② 无变更（持仓盈亏简报）
        rows, skipped, dd = plan()
        sample, demo_pos, demo_pnl = [], {}, []
        for r in rows:
            if r["sig"] == 0 or r["lots"] <= 0:
                continue
            c = dict(r)
            c["how"] = "开%s仓" % ("多" if r["sig"] > 0 else "空")
            c["basis"] = ("长期升水（contango），做空收展期收益" if r["gap"] > CARRY_THR
                          else "长期贴水（backwardation），做多收展期收益")
            sample.append(c)
            # 造一个「3% 浮盈」的持仓，用来展示盈亏表长什么样
            ent = r["px"] * (1 - 0.03 * r["sig"])
            amt = (r["px"] - ent) * r["sig"] * r["lots"] * r["mult"]
            demo_pos[r["sym"]] = {"dir": r["sig"], "lots": r["lots"],
                                  "entry_px": ent, "entry_date": dd}
            demo_pnl.append({"sym": r["sym"], "name": r["name"], "dir": r["sig"],
                             "lots": r["lots"], "entry": ent, "entry_date": dd,
                             "px": r["px"], "mult": r["mult"], "amt": amt,
                             "pct": amt / (ent * r["mult"] * r["lots"])})
        for tag, ch in (("样例1·有变更", sample), ("样例2·无变更", [])):
            subj, text, html = _build_mail(rows, ch, dd, demo_pos, demo_pnl,
                                           0.0, EQUITY, dd)
            ok, m = send_mail("[%s] %s" % (tag, subj), text, html)
            print("%s  →  %s" % (tag, m))
            if not ok:
                print("（提示：检查 MAIL 里的授权码 / 收发件人）")
