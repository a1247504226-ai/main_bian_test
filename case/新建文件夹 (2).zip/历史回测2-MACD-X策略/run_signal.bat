@echo off
REM ============================================================================
REM  MACD-X daily signal check + email push        (run_signal.bat)
REM
REM  Schedule: 08:01 Beijing time daily.
REM  Binance daily candles close at UTC 00:00 = 08:00 Beijing, so 08:01 picks up
REM  the just-closed daily bar, and 1 minute is enough for the API to update.
REM
REM  Logging: ONE FILE PER MONTH -> logs\macdx_YYYYMM.log
REM  Every run appends to the same monthly file, so nothing is ever replaced.
REM  On the 1st of a new month the name changes automatically
REM  (e.g. macdx_202609.log -> macdx_202610.log) and a fresh file is created.
REM  Old months are KEPT - there is no rotation and no deletion.
REM
REM  WHY THIS FILE IS PURE ASCII:
REM    cmd.exe parses .bat files using the console codepage (GBK on Chinese
REM    Windows). Non-ASCII bytes in a .bat get mis-aligned and swallow the
REM    following characters, producing bogus "not a valid command" errors.
REM    Keeping the whole file ASCII removes that entire class of bug.
REM    The log is written by Python in UTF-8 (with BOM) instead - one encoding
REM    only, so it never gets garbled. Do NOT redirect this script's output
REM    with ">>": cmd's %date% expands to Chinese on some locales and would mix
REM    GBK bytes into the UTF-8 log.
REM
REM  REGISTER THE SCHEDULED TASK (run once in an ADMIN cmd):
REM    schtasks /Create /TN "MACD-X-Daily" /TR "C:\Users\hongji\WorkBuddy AI\2026-09-29-16-53-45\run_signal.bat" /SC DAILY /ST 08:01 /F
REM
REM  View:   schtasks /Query /TN "MACD-X-Daily" /V /FO LIST
REM  Run:    schtasks /Run /TN "MACD-X-Daily"
REM  Delete: schtasks /Delete /TN "MACD-X-Daily" /F
REM
REM  NOTE: Task Scheduler by default runs tasks only when the user is logged on,
REM  and skips them while the PC is off/asleep. For reliability, open the
REM  Task Scheduler GUI afterwards and tick:
REM     [V] Run whether user is logged on or not
REM     [V] Run as soon as possible after a scheduled start is missed
REM ============================================================================

REM UTF-8 console so Python's output shows correctly; safe because this file is ASCII
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"

REM ==== Symbols and order sizing (edit these three lines) ====
set SYMBOLS=BTCUSDT ETHUSDT BNBUSDT SOLUSDT DOGEUSDT
set CAPITAL=1000
set FRAC=0.7

REM ==== Locate Python: isolated runtime first, then system install, then PATH ====
set PY=
if exist "C:\Users\hongji\.workbuddy-ai\binaries\python\versions\3.13.12\python.exe" set PY=C:\Users\hongji\.workbuddy-ai\binaries\python\versions\3.13.12\python.exe
if not defined PY if exist "C:\Users\hongji\AppData\Local\Programs\Python\Python39\python.exe" set PY=C:\Users\hongji\AppData\Local\Programs\Python\Python39\python.exe
if not defined PY for /f "delims=" %%i in ('where python 2^>nul') do if not defined PY set PY=%%i
if not defined PY (
    if not exist logs mkdir logs
    echo %date% %time% [ERROR] python.exe not found >> logs\_bat_error.log
    echo [ERROR] python.exe not found. Edit the PY variable in run_signal.bat
    pause
    exit /b 1
)

REM ==== Log file: ONE PER MONTH, logs\macdx_YYYYMM.log ====
if not exist logs mkdir logs
set TODAY=
for /f "delims=" %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd" 2^>nul') do set TODAY=%%i
REM Fallback if PowerShell is unavailable. %date% is locale-dependent but works
REM on Chinese Windows, where it expands to something like 2026/09/30.
if not defined TODAY set TODAY=%date:~0,4%%date:~5,2%%date:~8,2%
REM First 6 chars of yyyyMMdd = yyyyMM
set LOGMONTH=%TODAY:~0,6%
REM Guard: if both date sources failed, avoid a file named macdx_unknow.log
echo %LOGMONTH%|findstr /r "^[0-9][0-9][0-9][0-9][0-9][0-9]$" >nul
if errorlevel 1 set LOGMONTH=unknown
set LOG=logs\macdx_%LOGMONTH%.log

REM ==== Run. Python writes the log itself (UTF-8 with BOM); no redirection here. ====
"%PY%" macdx_strategy.py --symbols %SYMBOLS% --signal --capital %CAPITAL% --frac %FRAC% --log-file "%LOG%"
set RC=%ERRORLEVEL%

exit /b %RC%
